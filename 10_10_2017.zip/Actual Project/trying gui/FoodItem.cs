﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trying_gui
{
    public class FoodItem : IEquatable<FoodItem>
    {
        public string BoxDrink = "";
        public string name = "";
        public string Name
        {
            get
            {
                return $"{SizeName}{name} {BoxDrink}";
            }
            set
            {
                name = value;
            }
        }
        public string Description { get; set; }
        public virtual int Quantity { get; set; } = 1;
        public double price = 1;

        public virtual double Price
        {
            get
            {
                return price * Quantity * Size;
            }
            set
            {
                price = value;
            }
        }

        public string SmallSizeName = "";
        public string StandardSizeName = "";
        public string LargeSizeName = "";
        private string SizeName
        {
            get
            {
                return SmallSizeName + StandardSizeName + LargeSizeName;
            }
        }

        public double Size = 1;

        public FoodItem(string name, string Des, double price)
        {
            this.name = name;
            Description = Des;
            this.price = price;

            SmallSizeName = "";
            StandardSizeName = "";
            LargeSizeName = "";
            BoxDrink = "";
        }
        public override string ToString()
        {
            return string.Format("{2} X {0}   R{1}", Name, Math.Round(Price, 2), Quantity);
        }

        public bool Equals(FoodItem other)
        {
            return (BoxDrink.ToLower() == other.BoxDrink.ToLower() && Name.ToLower() == other.Name.ToLower());
        }
    }
}
