﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Defining_Classes
{
    class FoodItem
    {
        public string Name { get; set;}
        public string Description { get; set; }
        public double Price { get; set; }
        public size Size { get; set; }

        //It will be in the constructor so that when the object is created the price for the sizes is alrady defined
        private double PriceForSizes(StreamReader R)
        {
            if (Size == size.Small)
            {
                return 0.00; //The price from the file, which is the standard price, multiplied by 60% (Or however much we say it will be)
            }
            
            if (Size == size.Standard)
            {
                return 1.00; //The price from the file
            }

            if (Size == size.Large)
            {
                return 2.00; //The price from the file multiplied by 140% (or however much we say it will be)
            }

            return 0.00;
        }

        public FoodItem (string name, string description, double price, size Size)
        {

        }
    }
}
