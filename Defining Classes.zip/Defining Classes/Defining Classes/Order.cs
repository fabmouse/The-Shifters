﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Defining_Classes
{
    class Order
    {
        List <FoodItem> Orders { get; set; }

        public Order()
        {
            Orders = new List<FoodItem>();
        }
    }
}
