﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Defining_Classes
{
    class Drinks
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public size Size { get; set; }

        //It won't be in the constructor because then if the drink is in the BoxItems then there will be a problem with the pricing 
        private double PriceForSizes(StreamReader R)
        {
            if (Size == size.Small)
            {
                return 0.00; //The price from the file, which is the standard price, multiplied by 60% (Or however much we say it will be)
            }

            if (Size == size.Standard)
            {
                return 1.00; //The price from the file
            }

            if (Size == size.Large)
            {
                return 2.00; //The price from the file multiplied by 140% (or however much we say it will be)
            }

            return 0.00;
        }
    }
}
