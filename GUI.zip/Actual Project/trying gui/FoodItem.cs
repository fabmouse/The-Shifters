﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trying_gui
{
    class FoodItem 
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int Quantity = 1;
        public double price;
        public virtual double Price
        {
            get
            {
                return price * Quantity * Size;
            }

            set
            {
                price = value;
            }
        }

        public string SmallSizeName = "";
        public string StandardSizeName = "";
        public string LargeSizeName = "";
        private string SizeName {
            get
            {
                return SmallSizeName + StandardSizeName + LargeSizeName;
            }
        }


        //public size Size
        //{
        //    get
        //    {
        //        return sz;
        //    }
        //}
 
        public double Size = 1;



        //{
        //    if (Size == size.Small)
        //    {
        //        Price = Price * 0.06;
        //    }

        //    if (Size == size.Standard)
        //    {
        //        Price = Price;
        //    }

        //    if (Size == size.Large)
        //    {
        //        Price = Price * 1.40;
        //    



        public FoodItem(string name, string Des, double price)
            {
                Name = name;
                Description = Des;
                Price = price;

            }
        public override string ToString()
        {
            return string.Format("{2} X {3} {0}   R{1}", Name, Math.Round(Price, 2), Quantity, SizeName);
        }
    }
}
