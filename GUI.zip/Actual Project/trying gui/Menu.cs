﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace trying_gui
{
    class Menu
    {
        public List<FoodItem> Foods { get; set; }

        public List<FoodItem> Extras { get; set; }
        public List<BoxItems> BoxItems { get; set; }
        public List<FoodItem> Sodas { get; set; }
        public List<FoodItem> Desserts { get; set; }
        public List<FoodItem> Drinks { get; set; }

        public Menu()
        {
            Foods = new List<FoodItem> { };
            Extras = new List<FoodItem> { };
            Desserts = new List<FoodItem> { };
            BoxItems = new List<BoxItems> { };
            Sodas = new List<FoodItem> { };
            Drinks = new List<FoodItem> { };

        }
        public void Load(string filename)
        {
            string readMenu = File.ReadAllText(filename);
            string[] Food = readMenu.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

            string Topic = "";
      

            for(int i = 0; i < Food.Length; i++) {
                string Item = Food[i];
                string[] Temp = Item.Split(';');
                if (!Item.Contains(';')){
                    Topic = Item;
                    i++;
                    Item = Food[i];
                    Temp = Item.Split(';');
                }
                if (Topic == "BURGERS" || Topic == "PIZZAS")
                {
                    Foods.Add(new FoodItem(Temp[0], Temp[1], Convert.ToDouble(Temp[2])));
                }

                if (Topic == "EXTRAS")
                {
                    Extras.Add(new FoodItem(Temp[0], Temp[1], Convert.ToDouble(Temp[2])));
                }
                if (Topic == "DESSERTS")
                {
                    Desserts.Add(new FoodItem(Temp[0], Temp[1], Convert.ToDouble(Temp[2])));
                }
                if (Topic == "BOXMEALS")
                {
                    BoxItems.Add(new BoxItems(Temp[0], Temp[1], Convert.ToDouble(Temp[2])));
                }
                if (Topic == "SODAS")
                {
                    Sodas.Add(new FoodItem(Temp[0], Temp[1], Convert.ToDouble(Temp[2])));
                }
                if (Topic == "DRINKS")
                {
                    Drinks.Add(new FoodItem(Temp[0], Temp[1], Convert.ToDouble(Temp[2])));
                }
            }
        }

        }
    }
