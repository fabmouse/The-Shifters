﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trying_gui
{
    class Drivers
    {
        public List<Order> Orders { get; set; }

        public Drivers()
        {
            Orders = new List<Order>();
        }
    }
}
