﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trying_gui
{
    class BoxItems : FoodItem
    {
        public string BoxDrink;

        public string name = "";
        //public override string Name
        //{
        //    get
        //    {
        //        return name + " with " + BoxDrink;
        //    }

        //    set
        //    {
        //        name = value;
        //    }

        //}

        //public string Description
        //{
        //    get;

        //    set;
        //}

        //public size Size
        //{
        //    get;

        //    set;
        //}

        public override double Price
        {
            get
            {
                return price * BoxQuantity;
            }

            set
            {
                price = value;
            }
        }

        public int BoxQuantity = 1;

       public double price;

        public BoxItems(string name, string Des, double price) : base(name, Des, price)
        {

            Name = name;
            Description = Des;
            Price = price;
        }

        public override string ToString()
        {
            return string.Format("{2} X {0}   R{1}", Name, Math.Round(Price, 2), BoxQuantity);
        }
    }
}
