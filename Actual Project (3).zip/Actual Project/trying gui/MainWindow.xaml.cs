﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Threading;


namespace trying_gui
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// defining the images
    public enum size : long { Small = (long) 0.5 , Standard = 1, Large = (long) 1.5 }
    public partial class MainWindow : Window
    {
        DispatcherTimer TheTimer;
        public int currentstate = 0;
        int OrderNumber = 1;
        string CampusName = "";
        public BitmapImage[] Cartpic;
        string imageintheproject = "pack://application:,,,/";
        Order CurrentOrder;
       
        List<BoxItems> BoxItemTemp;
        Menu FullMenu;

        Dictionary<string, string> TellerPasswords;
        Dictionary<string, string> ManagerPasswords;

        List<string> LowerCampus;
        List<string> MiddleCampus;
        List<string> UpperCampus;

        Drivers LowerDriver;
        Drivers MiddleDriver;
        Drivers UpperDriver;
        Drivers Takeaway;

        //List<Order> LowerOrders;
        //List<Order> MiddleOrders;
        //List<Order> UpperOrders;
        public MainWindow()
        {
            InitializeComponent();
            // Canvas visibility
            maindoor.Visibility = Visibility.Visible;
            managerside.Visibility = Visibility.Hidden;
            employeeside.Visibility = Visibility.Hidden;
            EmployeeLogin.Visibility = Visibility.Hidden;
            ManagerLogin.Visibility = Visibility.Hidden;
            Cartpic = new BitmapImage[] {
                new BitmapImage(new Uri( imageintheproject+"shopping_cart.png"))
                };

            //Initialise Timer
            TheTimer = new DispatcherTimer();
            TheTimer.Interval = TimeSpan.FromMilliseconds(100);
            TheTimer.IsEnabled = true;
            TheTimer.Tick += dispatcherTimer_Tick;


            //Uploading Menu:
            //1.Food Itmes: burgers and pizza
            FullMenu = new Menu();
            CurrentOrder = new Order();
            BoxItemTemp = new List<BoxItems>();

            if (File.Exists("Food.txt"))
            {
                FullMenu.Load("Food.txt");
            }
            FoodLB.ItemsSource = FullMenu.Foods;
            ExtrasLB.ItemsSource = FullMenu.Extras;
            DrinksLB.ItemsSource = FullMenu.Drinks;
            BoxMealsLB.ItemsSource = FullMenu.BoxItems;
            SodasLB.ItemsSource = FullMenu.Sodas;
            DessertLB.ItemsSource = FullMenu.Desserts;
            OrderLB.ItemsSource = CurrentOrder.Orders;


            //CAMPUSES
            LowerCampus = new List<string>();
            MiddleCampus = new List<string>();
            UpperCampus = new List<string>();
            if (File.Exists("Campuses.txt"))
            {
                LoadCampuses("Campuses.txt", LowerCampus, MiddleCampus, UpperCampus);
            }


            LowerDriver = new Drivers();
            MiddleDriver = new Drivers();
            UpperDriver = new Drivers();
            Takeaway = new Drivers();

            //   TakeawayLB.ItemsSource = FullMenu.Foods;
            LCD_LB.ItemsSource = LowerDriver.Orders;
            MCD_LB.ItemsSource = MiddleDriver.Orders;
            UCD_LB.ItemsSource = UpperDriver.Orders;
            Takeaway_LB.ItemsSource = Takeaway.Orders;

            //PASSWORDS

            if (File.Exists("Teller Passwords.txt"))
            {
                TellerPasswords = LoadTellerPasswords("Teller Passwords.txt");
            }

            if (File.Exists("Manager Passwords.txt"))
            {
                ManagerPasswords = LoadManagerPasswords("Manager Passwords.txt");
            }

        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
       
        }

        //void dissapear()
        //{
        //    if (manager.IsPressed == true)
        //    {
        //        managerside.Visibility = Visibility.Visible;
        //    }
        //    else managerside.Visibility = Visibility.Hidden;
        //    if (employee.IsPressed == true)
        //    {
        //        .Visibility = Visibility.Visible;

        //    }
        //    else
        //}
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            managerside.Visibility = Visibility.Visible;
            maindoor.Visibility = Visibility.Hidden;
            employeeside.Visibility = Visibility.Hidden;
        }

        private void employee_Click(object sender, RoutedEventArgs e)
        {
            employeeside.Visibility = Visibility.Visible;
            maindoor.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
            cartimage.Source = Cartpic[currentstate];
          //  EmployeeLogin.Visibility = Visibility.Visible;

        }

        private void logoutmanager_Click(object sender, RoutedEventArgs e)
        {
            maindoor.Visibility = Visibility.Visible;
            employeeside.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
        }

        private void logoutemployee_Click(object sender, RoutedEventArgs e)
        {
            employeeside.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
            maindoor.Visibility = Visibility.Visible;
        }

        private void cartimage_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void ListBoxItem_Selected(object sender, RoutedEventArgs e)
        {

        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ListBoxItem_Selected_1(object sender, RoutedEventArgs e)
        {

        }

        private void cartimage_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void checkBox4_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void BurgersLB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ItemPosB = FoodLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Foods[ItemPosB];
            FoodDesBox.Text = CurrentB.Description.ToString();
        }

        private void FoodDesBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        double CalculateTotal(Order CustOrder)
        {
            double total = 0;
            foreach (FoodItem Food in CustOrder.Orders)
            {
                total += Food.Price;
            }
            return total;

        }
        string CustomerReceipt(Order CustOrder, string Teller, double Cost)
        {
            string Header = "THE SHIFTERS CAFE\nGrahamstown\n012 3456 789";
            string Order = "";

            foreach(FoodItem Food in CustOrder.Orders)
            {
                Order += $"{Food.ToString()}\n";
            }

            return string.Format("{0}\n\nTeller: {1}\n\n{2}\n\nTotal: R{3}", Header, Teller, Order, Convert.ToString(Cost));
        }
        string DeliveryReceipt(Order CustOrder, string CN, string CC, string CA, string Teller, double Cost)
        {
            string Header = "THE SHIFTERS CAFE\nGrahamstown\n012 3456 789";
            string Order = "";
            string CustomerDetails = string.Format("Customer: {0}\nContact: {1}\nAddress: {2} ({3})", CN, CC, CA, CampusName);
            foreach (FoodItem Food in CustOrder.Orders)
            {
                Order += $"{Food.ToString()}\n";
            }

            return string.Format("{0}\n\n{1}\n\nTeller: {2}\n\n{3}\n\nTotal: R{4}\n\nOrder Number: {5}", Header, CustomerDetails, Teller, Order, Convert.ToString(Cost), OrderNumber);
        }
        string TakeawayReceipt(Order CustOrder, string Teller, double Cost, double paid, double change)
        {
            string Header = "THE SHIFTERS CAFE\nGrahamstown\n012 3456 789";
            string Order = "";
 
            foreach (FoodItem Food in CustOrder.Orders)
            {
                Order += $"{Food.ToString()}\n";
            }

            return string.Format("{0}\\n\nTeller: {1}\n\n{2}\n\nTotal: R{3}\nAmount Paid: R{5}\nChange: R{6}\n\nOrder Number: {4}", Header, Teller, Order, Convert.ToString(Cost), OrderNumber, paid, change);
        }
        //Add Item Buttons
        private void AddMeal_Btn_Click(object sender, RoutedEventArgs e)
        {
            int ItemPos = FoodLB.SelectedIndex;
            FoodItem CurrentA = FullMenu.Foods[ItemPos];
            int k = 0;

            //if (Food_Small.IsChecked == false && Food_Standard.IsChecked == false && Food_Large.IsChecked == false && CurrentB.Name.Contains("Pizza")) {
            //    MessageBox.Show("Please select a pizza size");
            //        }
            //|| (Food_Small.IsChecked == false && Food_Standard.IsChecked == false && Food_Large.IsChecked == false && CurrentB.Name.Contains("Pizza"))
            FoodItem CurrentB = new FoodItem(FullMenu.Foods[ItemPos].Name, FullMenu.Foods[ItemPos].Description, FullMenu.Foods[ItemPos].Price);

            if (Food_Small.IsChecked == true && CurrentB.Name.Contains("Pizza"))
                {
            
                CurrentB.Size = 0.5;
                    CurrentB.SmallSizeName = "Small";
                CurrentB.StandardSizeName = "";
                CurrentB.LargeSizeName = "";
                if (CurrentOrder.Orders.Count == 0)
                {
                    CurrentOrder.Orders.Add(CurrentB);
                }
                else
                {
                    while (k < CurrentOrder.Orders.Count)
                    {
                        if (CurrentOrder.Orders.Contains(CurrentB))
                        {
                            CurrentA.Quantity++;
                            break;
                        }
                        else
                        {
                            CurrentOrder.Orders.Add(CurrentB);
                            break;
                        }
                        k++;
                    }
                }
            }
                else if (Food_Standard.IsChecked == true && CurrentB.Name.Contains("Pizza"))
                {

                CurrentB.Size = 1;
                    CurrentB.StandardSizeName = "Standard";
                CurrentB.SmallSizeName = "";
                CurrentB.LargeSizeName = "";
                if (CurrentOrder.Orders.Count == 0)
                {
                    CurrentOrder.Orders.Add(CurrentB);
                }
                else
                {
                    while (k < CurrentOrder.Orders.Count)
                    {
                        if (CurrentOrder.Orders.Contains(CurrentA))
                        {
                            CurrentA.Quantity++;
                            break;
                        }
                        else
                        {
                            CurrentOrder.Orders.Add(CurrentB);
                            break;
                        }
                        k++;
                    }
                }
            }
                else if (Food_Large.IsChecked == true && CurrentB.Name.Contains("Pizza"))
                {
     
                CurrentB.Size = 1.5;
                    CurrentB.LargeSizeName = "Large";
                if (CurrentOrder.Orders.Count == 0)
                {
                    CurrentOrder.Orders.Add(CurrentB);
                }
                else
                {
                    while (k < CurrentOrder.Orders.Count)
                    {
                        if (CurrentOrder.Orders.Contains(CurrentB))
                        {
                            CurrentB.Quantity++;
                            break;
                        }
                        else
                        {
                            CurrentOrder.Orders.Add(CurrentB);
                            break;
                        }
                        k++;
                    }
                }
            }


            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));

            Food_Small.IsChecked = false;
            Food_Standard.IsChecked = false;
            Food_Large.IsChecked = false;

        }
        private void AddDessert_Btn_Click_1(object sender, RoutedEventArgs e)
        {
            int ItemPos = DessertLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Desserts[ItemPos];
            int k = 0;
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
            }
            else
            {
                while (k < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(CurrentB))
                    {
                        CurrentB.Quantity++;
                        break;
                    }
                    else
                    {
                        CurrentOrder.Orders.Add(CurrentB);
                        break;
                    }
                    k++;
                }
            }
            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }
        private void AddBoxitem_Btn_Click(object sender, RoutedEventArgs e)
        {
            //int ItemPos = 0;
            // int DrinkPos = 0;

            if (BoxMealsLB.SelectedIndex == -1 || SodasLB.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a BoxMeal and a drink.");
            }
            else
            { 
            int ItemPos = BoxMealsLB.SelectedIndex;
            int DrinkPos = SodasLB.SelectedIndex;
            FoodItem CurrentDrink = FullMenu.Sodas[DrinkPos];
            FoodItem CurrentB = FullMenu.Foods[ItemPos];
            BoxItems CurrentBoxItem = new BoxItems(CurrentB.Name + " with " + CurrentDrink, CurrentB.Description, CurrentB.Price);

                int k = 0;

                if (CurrentOrder.Orders.Count == 0)
                {
                    CurrentOrder.Orders.Add(CurrentB);
                    BoxItemTemp.Add(CurrentBoxItem);
                }
                else
                
                    while (k < CurrentOrder.Orders.Count)
                    {
                        if (CurrentOrder.Orders.Contains(CurrentB)) 
                        {
                            CurrentBoxItem.BoxQuantity++;
                            break;
                        }
                        else
                        {
                            CurrentOrder.Orders.Add(CurrentB);
                            BoxItemTemp.Add(CurrentBoxItem);
                            break;
                        }
                        k++;
                    }
            }


            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }
        private void AddDrink_Btn_Click(object sender, RoutedEventArgs e)
        {
            int ItemPos = DrinksLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Drinks[ItemPos];
            int k = 0;
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
            }
            else
            {
                while (k < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(CurrentB))
                    {
                        CurrentB.Quantity++;
                        break;
                    }
                    else
                    {
                        CurrentOrder.Orders.Add(CurrentB);
                        break;
                    }
                    k++;
                }
            }
            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }
        private void AddExtras_Btn_Click(object sender, RoutedEventArgs e)
        {
            int ItemPos = ExtrasLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Extras[ItemPos];
            int k = 0;
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
            }
            else
            {
                while (k < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(CurrentB))
                    {
                        CurrentB.Quantity++;
                        break;
                    }
                    else
                    {
                        CurrentOrder.Orders.Add(CurrentB);
                        break;
                    }
                    k++;
                }
            }
            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }

        Dictionary<string, string> LoadTellerPasswords(string filename)
        {
            string readTellers = File.ReadAllText(filename);
            string[] Tellers = readTellers.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

            Dictionary<string, string> TellerPassowrds = new Dictionary<string, string>();

            foreach (string Teller in Tellers)
            {
                string[] TempTeller = Teller.Split(';');
                TellerPassowrds[TempTeller[0]] = TempTeller[1];
            }

            return TellerPassowrds;
        }
        private void Tell_Login_Btn_Click(object sender, RoutedEventArgs e)
        {
            string CurrentUser = Tell_User_TB.Text;
            string CurrentPassword = Tell_Pass_TB.Text;
            try
            {
                if (TellerPasswords.ContainsKey(CurrentPassword))
                {
                    if (CurrentUser == TellerPasswords[CurrentPassword])
                    {
                        EmployeeLogin.Visibility = Visibility.Hidden;
                        employeeside.Visibility = Visibility.Visible;
                    }
                }


            }
            catch 
            {
                MessageBox.Show("Username or Passwrd is incorrect");
            }
      

            

        }

        private void OrderDone_Btn_Click(object sender, RoutedEventArgs e)
        {
       
            string CustomerName = CustName_TB.Text;
            string CustomerContact = CustCont_TB.Text;
            string CustomerAddress = CustAddress_TB.Text;
            string Teller = Teller_TB.Text;

            double CustTotal = CalculateTotal(CurrentOrder);
           

            if (Delivery_CB.IsChecked == true)
            {
                Takeaway_CB.IsChecked = false;
                if (CustomerName == "" || CustomerContact == "" || CustomerAddress == "")
                {
                    MessageBox.Show("Please supply customer details");
                }
                else
                {
                    if (LowerCampus.Contains(CustomerAddress))
                    {
                        LowerDriver.Orders.Add(CurrentOrder);
                        CampusName = "LOWER";
                        LCD_LB.Items.Refresh();
                    }
                    else if (MiddleCampus.Contains(CustomerAddress))
                    {
                        MiddleDriver.Orders.Add(CurrentOrder);
                        CampusName = "MIDDLE";
                        MCD_LB.Items.Refresh();
                    }
                    else if (UpperCampus.Contains(CustomerAddress))
                    {
                        UpperDriver.Orders.Add(CurrentOrder);
                        CampusName = "UPPER";
                        UCD_LB.Items.Refresh();
                    }
                    MessageBox.Show(CustomerReceipt(CurrentOrder, Teller, CustTotal));
                    MessageBox.Show(DeliveryReceipt(CurrentOrder, CustomerName, CustomerContact, CustomerAddress, Teller, CustTotal));
                }
            } else if (Takeaway_CB.IsChecked == true)
            {
                double AmtPaid = Convert.ToDouble(TotalPd_TB.Text);
                double Change = AmtPaid - CustTotal;
                Change_TB.Text = Convert.ToString(Change);

                Delivery_CB.IsChecked = false;
                Takeaway.Orders.Add(CurrentOrder);
                Takeaway_LB.Items.Refresh();
                MessageBox.Show(TakeawayReceipt(CurrentOrder, Teller, CustTotal, AmtPaid, Change));

            }

            CurrentOrder.orderNumber = OrderNumber;

            Takeaway_CB.IsChecked = false;
            Delivery_CB.IsChecked = false;

        }

        private void Delivery_CB_Checked(object sender, RoutedEventArgs e)
        {
             
        }

        private void Delivery_CB_Checked_1(object sender, RoutedEventArgs e)
        {
        }

        private void button_Click_1(object sender, RoutedEventArgs e)
        {
            int ItemPos = OrderLB.SelectedIndex;
            int k = 0;
            if (CurrentOrder.Orders.Count == 0 || OrderLB.SelectedIndex == -1)
            {
             
                MessageBox.Show("There is nothing to remove");
            }
            else
            {
                //ManagerLogin.Visibility = Visibility.Visible;
                FoodItem ItemToRemove = CurrentOrder.Orders[ItemPos];
                while (k < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(ItemToRemove))
                    {
                        if (ItemToRemove.Quantity > 1)
                        {
                            ItemToRemove.Quantity--;
                            break;
                        }
                        else
                        {
                            CurrentOrder.Orders.Remove(ItemToRemove);
                            break;
                        }
                        k++;
                    }
                }
            }
            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            OrderNumber ++;
            OrderNumber_TB.Text = Convert.ToString(OrderNumber);
            CurrentOrder = new Order();
            OrderLB.ItemsSource = CurrentOrder.Orders;
            Change_TB.Text = "";
            TotalPd_TB.Text = "";
            TotalCost_TB.Text = "";
            CustName_TB.Text = "";
            CustCont_TB.Text = "";
            CustAddress_TB.Text = "";
        }

        Dictionary<string, string> LoadManagerPasswords(string filename)
        {
            string readManagers = File.ReadAllText(filename);
            string[] Managers = readManagers.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

            Dictionary<string, string> ManagerPassowrds = new Dictionary<string, string>();

            foreach (string Manager in Managers)
            {
                string[] TempTeller = Manager.Split(';');
                ManagerPassowrds[TempTeller[0]] = TempTeller[1];
            }

            return ManagerPassowrds;
        }
        private void ManagerLogin_Btn_Click(object sender, RoutedEventArgs e)
        {
            string CurrentUser = Man_User_TB.Text;
            string CurrentPassword = Man_Pass_TB.Text;
            if (ManagerPasswords.ContainsKey(CurrentPassword))
            {
                if (CurrentUser == ManagerPasswords[CurrentPassword])
                {
                    ManagerLogin.Visibility = Visibility.Hidden;
                }
            }
        }

        public void LoadCampuses(string filename, List<string> Lower, List<string> Middle, List<string> Upper)
        {

            string readAddresses = File.ReadAllText(filename);
            string[] Res = readAddresses.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

            string Campus = "";


            for (int i = 0; i < Res.Length; i++)
            {
                string Item = Res[i];
                string[] Temp = Item.Split(':');
                if (Item.Contains(':'))
                {
                    Campus = Item.Split(':')[1];
                    i++;
                    Item = Res[i];
                }
                if (Campus == "LOWER")
                {
                    Lower.Add(Item);
                }

                if (Campus == "MIDDLE")
                {
                    Middle.Add(Item);
                }
                if (Campus == "UPPER")
                {
                    Upper.Add(Item);
                }
            }
        }
    }
}
