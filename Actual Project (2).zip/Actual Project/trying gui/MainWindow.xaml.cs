﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;


namespace trying_gui
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// defining the images
    public enum size { Small = 1, Standard = 2, Large = 3 }
    public partial class MainWindow : Window
    {
        public int currentstate = 0;
        public BitmapImage[]Cartpic;
        string imageintheproject = "pack://application:,,,/";
        Order CurrentOrder;
        Menu FullMenu;
        public MainWindow()
        {
            InitializeComponent();
            maindoor.Visibility = Visibility.Visible;
            managerside.Visibility = Visibility.Hidden;
            employeeside.Visibility = Visibility.Hidden;
            Cartpic = new BitmapImage[] {
                new BitmapImage(new Uri( imageintheproject+"shopping_cart.png"))
                };

            //Uploading Menu:
            //1.Food Itmes: burgers and pizza
            FullMenu = new Menu();
            CurrentOrder = new Order();
            if (File.Exists("Food.txt"))
            {
                FullMenu.Load("Food.txt");
            }
            FoodLB.ItemsSource = FullMenu.Foods;
            ExtrasLB.ItemsSource = FullMenu.Extras;
            DrinksLB.ItemsSource = FullMenu.Drinks;
            BoxMealsLB.ItemsSource = FullMenu.BoxItems;
            DessertLB.ItemsSource = FullMenu.Desserts;
            OrderLB.ItemsSource = CurrentOrder.Orders;

           
        }
        //void dissapear()
        //{
        //    if (manager.IsPressed == true)
        //    {
        //        managerside.Visibility = Visibility.Visible;
        //    }
        //    else managerside.Visibility = Visibility.Hidden;
        //    if (employee.IsPressed == true)
        //    {
        //        .Visibility = Visibility.Visible;

        //    }
        //    else
        //}
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            managerside.Visibility = Visibility.Visible;
            maindoor.Visibility = Visibility.Hidden;
            employeeside.Visibility = Visibility.Hidden;
        }

        private void employee_Click(object sender, RoutedEventArgs e)
        {
            employeeside.Visibility = Visibility.Visible;
            maindoor.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
            cartimage.Source = Cartpic[currentstate];
            
        }

        private void logoutmanager_Click(object sender, RoutedEventArgs e)
        {
            maindoor.Visibility = Visibility.Visible;
            employeeside.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
        }

        private void logoutemployee_Click(object sender, RoutedEventArgs e)
        {
            employeeside.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
            maindoor.Visibility = Visibility.Visible;
        }

        private void cartimage_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void ListBoxItem_Selected(object sender, RoutedEventArgs e)
        {

        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ListBoxItem_Selected_1(object sender, RoutedEventArgs e)
        {

        }

        private void cartimage_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void checkBox4_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void BurgersLB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ItemPosB = FoodLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Foods[ItemPosB];
            FoodDesBox.Text = CurrentB.Description.ToString();
        }

        private void FoodDesBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }



        private void AddMeal_Btn_Click(object sender, RoutedEventArgs e)
        {

            int ItemPosB = FoodLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Foods[ItemPosB];
            CurrentOrder.Orders.Add(CurrentB);

            OrderLB.Items.Refresh();

        }




        private void AddDessert_Btn_Click_1(object sender, RoutedEventArgs e)
        {

            int ItemPosB = DessertLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Desserts[ItemPosB];
            CurrentOrder.Orders.Add(CurrentB);

            OrderLB.Items.Refresh();

        }
    }
}
