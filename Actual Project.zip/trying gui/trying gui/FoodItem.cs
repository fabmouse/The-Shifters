﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trying_gui
{
    class FoodItem
    {
            public string Name { get; set; }
            private string Description { get; set; }
            public double Price
            {
                get { return Price; }
                set
                {
                    if (Size == size.Small)
                    {
                        Price = Price * 0.06 * Quantity;
                    }

                    if (Size == size.Standard)
                    {
                        Price = Price * Quantity;
                    }

                    if (Size == size.Large)
                    {
                        Price = Price * 1.40 * Quantity;
                    }
                }
            }
            public size Size { get; set; }
            public int Quantity { get; set; }

            public FoodItem(string name, string description, int quantity, size size, double price)
            {
                Name = name;
                Description = description;
                Price = price;
                Size = size;
                Quantity = quantity;
            }
    }
}
