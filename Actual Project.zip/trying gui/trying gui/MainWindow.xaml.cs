﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace trying_gui
{
    public enum size { Small = 1, Standard = 2, Large = 3 }

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// defining the images

    public partial class MainWindow : Window
    {
        //Defining this "current.." so that we will work with this instead of having to define all of the 
        //things in the menu as an object. Also this "current.." will work well because when the item, whether it is an 
        //individual item or a box item, is picked/clicked
        //from the GUI, we will instansiate the object with the relevant item.
        FoodItem CurrentFoodItem;
        Order CurrentOrder;
        List<FoodItem> CurrentFoodItems;
        List<Order> CurrentOrders;
        List<Drivers> DriversOnDuty;

        public int currentstate = 0;
        public BitmapImage[]Cartpic;
        string imageintheproject = "pack://application:,,,/";
        public MainWindow()
        {
            InitializeComponent();
            CurrentFoodItems = new List<FoodItem>();
            CurrentOrders = new List<Order>();
            DriversOnDuty = new List<Drivers>();

            maindoor.Visibility = Visibility.Visible;
            managerside.Visibility = Visibility.Hidden;
            employeeside.Visibility = Visibility.Hidden;
            Cartpic = new BitmapImage[] {
                new BitmapImage(new Uri( imageintheproject+"shopping_cart.png"))
                };
        }
        //void dissapear()
        //{
        //    if (manager.IsPressed == true)
        //    {
        //        managerside.Visibility = Visibility.Visible;
        //    }
        //    else managerside.Visibility = Visibility.Hidden;
        //    if (employee.IsPressed == true)
        //    {
        //        .Visibility = Visibility.Visible;

        //    }
        //    else
        //}
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            managerside.Visibility = Visibility.Visible;
            maindoor.Visibility = Visibility.Hidden;
            employeeside.Visibility = Visibility.Hidden;
        }

        private void employee_Click(object sender, RoutedEventArgs e)
        {
            employeeside.Visibility = Visibility.Visible;
            maindoor.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
            cartimage.Source = Cartpic[currentstate];
            
        }

        private void logoutmanager_Click(object sender, RoutedEventArgs e)
        {
            maindoor.Visibility = Visibility.Visible;
            employeeside.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
        }

        private void logoutemployee_Click(object sender, RoutedEventArgs e)
        {
            employeeside.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
            maindoor.Visibility = Visibility.Visible;
        }

        private void button15_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
