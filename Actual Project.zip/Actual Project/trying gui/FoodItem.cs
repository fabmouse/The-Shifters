﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trying_gui
{
    class FoodItem
    {
            public string Name { get; set; }
            public string Description { get; set; }
            public double Price { get; set; }
                //{
                //    if (Size == size.Small)
                //    {
                //        Price = Price * 0.06;
                //    }

                //    if (Size == size.Standard)
                //    {
                //        Price = Price;
                //    }

                //    if (Size == size.Large)
                //    {
                //        Price = Price * 1.40;
                //    }



            public size Size { get; set; }
            public int Quantity = 1;

        public override string  ToString()
        {
            return string.Format("{2} X {0}   R{1}", Name, Math.Round(Price, 2), Quantity);
        }

        public FoodItem(string name, string Des, double price)
            {
                Name = name;
                Description = Des;
                Price = price;
                size sz = Size;
                
            }
    }
}
