﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Threading;


namespace trying_gui
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// defining the images
    public enum size : long { Small = (long) 0.5 , Standard = 1, Large = (long) 1.5 }
    public partial class MainWindow : Window
    {
        DispatcherTimer TheTimer;
        public int currentstate = 0;
        int OrderNumber = 1;
        double CumulativeTotal = 0.0;
        string CampusName = "";
        string TellerID = "";
        string ManagerID = "";
        public BitmapImage[] Cartpic;
        string imageintheproject = "pack://application:,,,/";
        Order CurrentOrder;
        string ordernumber = "";
        List<BoxItems> BoxItemTemp;
        Menu FullMenu;

        Dictionary<string, string> TellerPasswords;
        Dictionary<string, string> ManagerPasswords;

        List<string> LowerCampus;
        List<string> MiddleCampus;
        List<string> UpperCampus;

        Drivers LowerDriver;
        Drivers MiddleDriver;
        Drivers UpperDriver;
        Drivers Takeaway;

        //List<Order> LowerOrders;
        //List<Order> MiddleOrders;
        //List<Order> UpperOrders;
        public MainWindow()
        {
            InitializeComponent();
            // Canvas visibility
            maindoor.Visibility = Visibility.Visible;
            managerside.Visibility = Visibility.Hidden;
            employeeside.Visibility = Visibility.Hidden;
            EmployeeLogin.Visibility = Visibility.Hidden;
            ManagerLogin.Visibility = Visibility.Hidden;
        

            //Initialise Timer
            TheTimer = new DispatcherTimer();
            TheTimer.Interval = TimeSpan.FromMilliseconds(100);
            TheTimer.IsEnabled = true;
            TheTimer.Tick += dispatcherTimer_Tick;


            //Uploading Menu:
            //1.Food Itmes: burgers and pizza
            FullMenu = new Menu();
            CurrentOrder = new Order();
            BoxItemTemp = new List<BoxItems>();

            if (File.Exists("Food.txt"))
            {
                FullMenu.Load("Food.txt");
            }
            FoodLB.ItemsSource = FullMenu.Foods;
            ExtrasLB.ItemsSource = FullMenu.Extras;
            DrinksLB.ItemsSource = FullMenu.Drinks;
            BoxMealsLB.ItemsSource = FullMenu.BoxItems;
            SodasLB.ItemsSource = FullMenu.Sodas;
            DessertLB.ItemsSource = FullMenu.Desserts;
            OrderLB.ItemsSource = CurrentOrder.Orders;


            //CAMPUSES
            LowerCampus = new List<string>();
            MiddleCampus = new List<string>();
            UpperCampus = new List<string>();
            if (File.Exists("Campuses.txt"))
            {
                LoadCampuses("Campuses.txt", LowerCampus, MiddleCampus, UpperCampus);
            }


            LowerDriver = new Drivers();
            MiddleDriver = new Drivers();
            UpperDriver = new Drivers();
            Takeaway = new Drivers();

            //   TakeawayLB.ItemsSource = FullMenu.Foods;
            LCD_LB.ItemsSource = LowerDriver.Orders;
            MCD_LB.ItemsSource = MiddleDriver.Orders;
            UCD_LB.ItemsSource = UpperDriver.Orders;
            Takeaway_LB.ItemsSource = Takeaway.Orders;

            //PASSWORDS

            if (File.Exists("Teller Passwords.txt"))
            {
                TellerPasswords = LoadTellerPasswords("Teller Passwords.txt");
            }

            if (File.Exists("Manager Passwords.txt"))
            {
                ManagerPasswords = LoadManagerPasswords("Manager Passwords.txt");
            }

        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
       
        }

        //void dissapear()
        //{
        //    if (manager.IsPressed == true)
        //    {
        //        managerside.Visibility = Visibility.Visible;
        //    }
        //    else managerside.Visibility = Visibility.Hidden;
        //    if (employee.IsPressed == true)
        //    {
        //        .Visibility = Visibility.Visible;

        //    }
        //    else
        //}
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            managerside.Visibility = Visibility.Hidden;
            maindoor.Visibility = Visibility.Hidden;
            employeeside.Visibility = Visibility.Hidden;
           ManagerLogin.Visibility = Visibility.Visible;
        }

        private void employee_Click(object sender, RoutedEventArgs e)
        {
            employeeside.Visibility = Visibility.Visible;
            maindoor.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
         //   cartimage.Source = Cartpic[currentstate];
          //EmployeeLogin.Visibility = Visibility.Visible;

        }

        private void logoutmanager_Click(object sender, RoutedEventArgs e)
        {
            maindoor.Visibility = Visibility.Visible;
            employeeside.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
        }

        private void logoutemployee_Click(object sender, RoutedEventArgs e)
        {
            employeeside.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
            maindoor.Visibility = Visibility.Visible;
        }

        private void cartimage_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void ListBoxItem_Selected(object sender, RoutedEventArgs e)
        {

        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ListBoxItem_Selected_1(object sender, RoutedEventArgs e)
        {

        }

        private void cartimage_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void checkBox4_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void FoodDesBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        //Loading Methods for Passwords and Residences
        Dictionary<string, string> LoadTellerPasswords(string filename)
        {
            string readTellers = File.ReadAllText(filename);
            string[] Tellers = readTellers.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

            Dictionary<string, string> TellerPassowrds = new Dictionary<string, string>();

            foreach (string Teller in Tellers)
            {
                string[] TempTeller = Teller.Split(';');
                TellerPassowrds[TempTeller[0]] = TempTeller[1];
            }

            return TellerPassowrds;
        }
        Dictionary<string, string> LoadManagerPasswords(string filename)
        {
            string readManagers = File.ReadAllText(filename);
            string[] Managers = readManagers.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

            Dictionary<string, string> ManagerPassowrds = new Dictionary<string, string>();

            foreach (string Manager in Managers)
            {
                string[] TempTeller = Manager.Split(';');
                ManagerPassowrds[TempTeller[0]] = TempTeller[1];
            }

            return ManagerPassowrds;
        }
        public void LoadCampuses(string filename, List<string> Lower, List<string> Middle, List<string> Upper)
        {

            string readAddresses = File.ReadAllText(filename);
            string[] Res = readAddresses.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);
            string Campus = "";

            for (int i = 0; i < Res.Length; i++)
            {
                string Item = Res[i];
                string[] Temp = Item.Split(':');
                if (Item == "")
                {
                    i++;
                    Item = Res[i];
                    Temp = Item.Split(':');
                }
                if (Item.Contains(':'))
                {
                    Campus = Item.Split(':')[1];
                    i++;
                    Item = Res[i];
                }
                if (Campus == "LOWER")
                {
                    Lower.Add(Item);
                }
                else if (Campus == "MIDDLE")
                {
                    Middle.Add(Item);
                }
                else if (Campus == "UPPER")
                {
                    Upper.Add(Item);
                }
            }
        }

        //Save Method for end of current day orders
//        public void SaveOrderToFile(string filename,Order CustOrder)
//        {

            


////File.AppendAllText(filename, order);

//     }

        //Displaying the description of each menu item
        private void BurgersLB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ItemPosB = FoodLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Foods[ItemPosB];
            FoodDesBox.Text = CurrentB.Description.ToString();
        }
        private void ExtrasLB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ItemPosB = ExtrasLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Extras[ItemPosB];
            ExtrasDes_TB.Text = CurrentB.Description.ToString();
        }
        private void BoxMealsLB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ItemPosB = BoxMealsLB.SelectedIndex;
            BoxItems CurrentB = FullMenu.BoxItems[ItemPosB];
            BoxDes_TB.Text = CurrentB.Description.ToString();
        }
        private void DessertLB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ItemPosB = DessertLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Desserts[ItemPosB];
            DessertDes_TB.Text = CurrentB.Description.ToString();
        }
        private void DrinksLB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ItemPosB = DrinksLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Drinks[ItemPosB];
            DrinksDes_TB.Text = CurrentB.Description.ToString();
        }
    

        //Add Item Buttons
        private void AddMeal_Btn_Click(object sender, RoutedEventArgs e)
        {
            //Burger Things
            int ItemPos = FoodLB.SelectedIndex;
            FoodItem CurrentBurger = FullMenu.Foods[ItemPos];
            int j = 0;
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentBurger);
            }
            else
            {
                while (j < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(CurrentBurger))
                    {
                        CurrentBurger.Quantity++;
                        break;
                    }
                    else
                    {
                        CurrentOrder.Orders.Add(CurrentBurger);
                        break;
                    }
                    j++;
                }
            }


            //Pizza Things
            int k = 0;

            if (Food_Small.IsChecked == false && Food_Standard.IsChecked == false && Food_Large.IsChecked == false && FullMenu.Foods[ItemPos].Name.Contains("Pizza"))
            {
                MessageBox.Show("Please select a pizza size");
            }
            else
            {
                FoodItem CurrentA = new FoodItem(FullMenu.Foods[ItemPos].Name, FullMenu.Foods[ItemPos].Description, FullMenu.Foods[ItemPos].price);
                //CurrentA.SmallSizeName = "Small";
                CurrentA.StandardSizeName = "";
                CurrentA.LargeSizeName = "";
                FoodItem CurrentB = new FoodItem(FullMenu.Foods[ItemPos].Name, FullMenu.Foods[ItemPos].Description, FullMenu.Foods[ItemPos].price);
                CurrentB.SmallSizeName = "";
                //CurrentA.StandardSizeName = "Standard";
                CurrentB.LargeSizeName = "";
                // FoodItem CurrentC = new FoodItem(FullMenu.Foods[ItemPos].Name, FullMenu.Foods[ItemPos].Description, FullMenu.Foods[ItemPos].price);
                //CurrentB.SmallSizeName = "Small";
                if (Food_Small.IsChecked == true && (CurrentA.Name.Contains("Pizza")) && CurrentOrder.Orders.Count == 1)
                {
                    CurrentA.Size = 0.5;
                    //CurrentA.SmallSizeName = "Small";
                    if (CurrentOrder.Orders.Count == 0)
                    {
                        CurrentOrder.Orders.Add(CurrentA);
                    }
                    else
                    {
                        while (k < CurrentOrder.Orders.Count)
                        {
                            if (CurrentOrder.Orders[k].Name == CurrentA.Name && CurrentA.SmallSizeName == "Small")
                            {
                                CurrentOrder.Orders[k].Quantity++;
                                break;
                            }
                            else
                            {
                                CurrentA.Quantity = 1;
                                CurrentA.price = FullMenu.Foods[ItemPos].price;
                                CurrentA.name = FullMenu.Foods[ItemPos].name;
                                FoodItem CurrentTemp = new FoodItem(CurrentA.Name, CurrentA.Description, CurrentA.price);
                                CurrentTemp.StandardSizeName = "";
                                CurrentTemp.LargeSizeName = "";
                                CurrentTemp.SmallSizeName = "Small";
                                CurrentOrder.Orders.Add(CurrentTemp);
                                break;
                            }
                            k++;
                        }
                    }


                    if (Food_Standard.IsChecked == true && (CurrentB.Name.Contains("Pizza")))
                    {
                        //int ItemPos = FoodLB.SelectedIndex;
                        //FoodItem CurrentB = FullMenu.Foods[ItemPos];
                        CurrentB.Size = 1;
                        CurrentB.StandardSizeName = "Standard";
                        if (CurrentOrder.Orders.Count == 0)
                        {
                            CurrentOrder.Orders.Add(CurrentB);
                        }
                        else
                        {
                            while (k < CurrentOrder.Orders.Count)
                            {
                                if (CurrentOrder.Orders[k].Name == CurrentB.Name && CurrentB.StandardSizeName == "Standard")
                                {
                                    CurrentOrder.Orders[k].Quantity++;
                                    break;
                                }
                                else
                                {
                                    CurrentB.Quantity = 1;
                                    CurrentB.price = FullMenu.Foods[ItemPos].price;
                                    CurrentB.name = FullMenu.Foods[ItemPos].name;
                                    FoodItem CurrentTemp = new FoodItem(CurrentB.name, CurrentB.Description, CurrentB.price);
                                    CurrentTemp.SmallSizeName = "";
                                    CurrentTemp.LargeSizeName = "";
                                    CurrentTemp.StandardSizeName = "Standard";
                                    CurrentOrder.Orders.Add(CurrentTemp);
                                    break;
                                }
                                k++;
                            }
                        }
                    }
                    //}
                    //else if (Food_Large.IsChecked == true && CurrentB.Name.Contains("Pizza"))
                    //{

                    //CurrentB.Size = 1.5;
                    //    CurrentB.LargeSizeName = "Large";
                    //if (CurrentOrder.Orders.Count == 0)
                    //{
                    //    CurrentOrder.Orders.Add(CurrentB);
                    //}
                    //else
                    //{
                    //    while (k < CurrentOrder.Orders.Count)
                    //    {
                    //        if (CurrentOrder.Orders.Contains(CurrentB))
                    //        {
                    //            CurrentB.Quantity++;
                    //            break;
                    //        }
                    //        else
                    //        {
                    //            CurrentOrder.Orders.Add(CurrentB);
                    //            break;
                    //        }
                    //        k++;
                    //    }
                }
            }


            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));

            Food_Small.IsChecked = false;
            Food_Standard.IsChecked = false;
            Food_Large.IsChecked = false;
        }
        private void AddDessert_Btn_Click_1(object sender, RoutedEventArgs e)
        {
            int ItemPos = DessertLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Desserts[ItemPos];
            int k = 0;
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
            }
            else
            {
                while (k < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(CurrentB))
                    {
                        CurrentB.Quantity++;
                        break;
                    }
                    else
                    {
                        CurrentOrder.Orders.Add(CurrentB);
                        break;
                    }
                    k++;
                }
            }
            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }
        private void AddBoxitem_Btn_Click(object sender, RoutedEventArgs e)
        {
            if (BoxMealsLB.SelectedIndex == -1 || SodasLB.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a BoxMeal and a drink.");
            }
            else
            {
                int ItemPos = BoxMealsLB.SelectedIndex;
                int DrinkPos = SodasLB.SelectedIndex;
                double CurrentPrice = 0;

                FoodItem CurrentB = new FoodItem(FullMenu.BoxItems[ItemPos].Name, FullMenu.BoxItems[ItemPos].Description, FullMenu.BoxItems[ItemPos].Price);
                string CurrentName = FullMenu.BoxItems[ItemPos].Name;
                // CurrentB.BoxDrink = FullMenu.Sodas[DrinkPos].Name;
                //BoxItems CurrentBox = FullMenu.BoxItems[ItemPos];
                FoodItem CurrentC;
                int k = 0;
                if (CurrentOrder.Orders.Count == 0)
                {
                    CurrentOrder.Orders.Add(CurrentB);
                }
                else
                {
                    if (FullMenu.BoxItems[ItemPos].name == "Beef Burger Meal")
                    {
                        //    CurrentPrice = 70.99;
                        CurrentName = "Beef Burger Meal";
                        FullMenu.BoxItems[ItemPos].Name = CurrentName;

                    }
                    if (FullMenu.BoxItems[ItemPos].name == "Chicken Burger Meal")
                    {
                        //    CurrentPrice = 70.99;
                        CurrentName = "Chicken Burger Meal";
                        FullMenu.BoxItems[ItemPos].Name = CurrentName;

                    }
                    if (FullMenu.BoxItems[ItemPos].name == "Mutton Burger Meal")
                    {
                        //    CurrentPrice = 70.99;
                        CurrentName = "Mutton Burger Meal";
                        FullMenu.BoxItems[ItemPos].Name = CurrentName;

                    }
                    if (FullMenu.BoxItems[ItemPos].name == "Supreme Beef Burger Meal")
                    {
                        //    CurrentPrice = 70.99;
                        CurrentName = "Supreme Beef Burger Meal";
                        FullMenu.BoxItems[ItemPos].Name = CurrentName;

                    }
                    CurrentC = new FoodItem(FullMenu.BoxItems[ItemPos].name, FullMenu.BoxItems[ItemPos].Description, FullMenu.BoxItems[ItemPos].price);
                    CurrentC.BoxDrink = FullMenu.Sodas[DrinkPos].Name;
                    CurrentOrder.Orders.Add(CurrentC);
                    //CurrentOrder.Orders.Add(FullMenu.BoxItems[ItemPos]);

                    k++;

                }
                //if (CurrentOrder.Orders.Count == 0)
                //{
                //    CurrentOrder.Orders.Add(CurrentB);
                //}
                //else
                //{

                //    while (k < CurrentOrder.Orders.Count)
                //    {

                //        if (CurrentOrder.Orders[k].Equals(CurrentB))
                //        {
                //            CurrentB.BoxDrink = CurrentOrder.Orders[k].BoxDrink;
                //            CurrentOrder.Orders[k] = this.CurrentB;
                //            CurrentOrder.Orders.Remove(CurrentB);
                //            this.CurrentOrder.Orders[k].Quantity++;
                //            break;
                //        }
                //        else
                //        {
                //            if (FullMenu.BoxItems[ItemPos].name == "Beef Burger Meal")
                //            {
                //            //    CurrentPrice = 70.99;
                //                CurrentName = "Beef Burger Meal";
                //                FullMenu.BoxItems[ItemPos].Name = CurrentName;

                //            }
                //            if (FullMenu.BoxItems[ItemPos].name == "Chicken Burger Meal")
                //            {
                //                //    CurrentPrice = 70.99;
                //                CurrentName = "Chicken Burger Meal";
                //                FullMenu.BoxItems[ItemPos].Name = CurrentName;

                //            }
                //            if (FullMenu.BoxItems[ItemPos].name == "Mutton Burger Meal")
                //            {
                //                //    CurrentPrice = 70.99;
                //                CurrentName = "Mutton Burger Meal";
                //                FullMenu.BoxItems[ItemPos].Name = CurrentName;

                //            }
                //            if (FullMenu.BoxItems[ItemPos].name == "Supreme Beef Burger Meal")
                //            {
                //                //    CurrentPrice = 70.99;
                //                CurrentName = "Supreme Beef Burger Meal";
                //                FullMenu.BoxItems[ItemPos].Name = CurrentName;

                //            }
                //            CurrentC = new FoodItem(FullMenu.BoxItems[ItemPos].name, FullMenu.BoxItems[ItemPos].Description, FullMenu.BoxItems[ItemPos].price);
                //            CurrentOrder.Orders[k].Name = CurrentName;
                //            //CurrentC.Quantity = 1;
                //            CurrentC.BoxDrink = FullMenu.Sodas[DrinkPos].Name;
                //            CurrentOrder.Orders.Add(CurrentC);
                //            break;
                //        }
                //        k++;
                //    }

                //    int DrinkPos = SodasLB.SelectedIndex;
                //    int ItemPos = BoxMealsLB.SelectedIndex;
                //    BoxItems CurrentB = FullMenu.BoxItems[ItemPos];

                //    //FoodItem CurrentBoxItem = new BoxItems(CurrentB.Name /*+ " with " + CurrentDrink*/, CurrentB.Description, CurrentB.Price);

                //    int k = 0;

                //    if (CurrentOrder.Orders.Count == 0)
                //    {
                //        CurrentB.BoxDrink = FullMenu.Sodas[DrinkPos].Name;
                //        CurrentOrder.Orders.Add(CurrentB);
                //        //BoxItemTemp.Add(CurrentBoxItem);
                //    }
                //    else 
                //    {
                //        while (k < CurrentOrder.Orders.Count)
                //        {
                //            if (CurrentOrder.Orders.Contains(CurrentB) && FullMenu.Sodas[DrinkPos].Name == CurrentB.BoxDrink)
                //            {
                //                CurrentB.quantity++;
                //                break;
                //            }
                //            else /*if (FullMenu.Sodas[DrinkPos].Name != CurrentB.BoxDrink)*/
                //            {
                //                FoodItem CurrentDrink = FullMenu.Sodas[SodasLB.SelectedIndex];
                //                BoxItems CurrentC = new BoxItems (FullMenu.BoxItems[ItemPos].Name, FullMenu.BoxItems[ItemPos].Description, FullMenu.BoxItems[ItemPos].Price);
                //                CurrentC.BoxDrink = CurrentDrink.Name; 
                //                CurrentOrder.Orders.Add(CurrentC);
                //                //BoxItemTemp.Add(CurrentBoxItem);
                //                break;
                //            }
                //            k++;
                //        }                }
                //}
            }

            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }
        private void AddDrink_Btn_Click(object sender, RoutedEventArgs e)
        {
            int ItemPos = DrinksLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Drinks[ItemPos];
            int k = 0;
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
            }
            else
            {
                while (k < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(CurrentB))
                    {
                        CurrentB.Quantity++;
                        break;
                    }
                    else
                    {
                        CurrentOrder.Orders.Add(CurrentB);
                        break;
                    }
                    k++;
                }
            }
            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }
        private void AddExtras_Btn_Click(object sender, RoutedEventArgs e)
        {
            int ItemPos = ExtrasLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Extras[ItemPos];
            int k = 0;
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
            }
            else
            {
                while (k < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(CurrentB))
                    {
                        CurrentB.Quantity++;
                        break;
                    }
                    else
                    {
                        CurrentOrder.Orders.Add(CurrentB);
                        break;
                    }
                    k++;
                }
            }
            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }


        //Manager and Teller Login Buttons
        private void Tell_Login_Btn_Click(object sender, RoutedEventArgs e)
        {
            string CurrentTellerID = Tell_User_TB.Text;
            string CurrentPassword = Tell_Pass_TB.Text;
            if(CurrentTellerID == "" || CurrentPassword == "")
            {
                MessageBox.Show("TellerID or Password is missing.");
            } else if (TellerPasswords.ContainsKey(CurrentTellerID))
                {
                    if (CurrentPassword == TellerPasswords[CurrentTellerID])
                    {
                        EmployeeLogin.Visibility = Visibility.Hidden;
                        employeeside.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        MessageBox.Show("TellerID or Passwrd is incorrect.");
                    }
                } else
            {
                MessageBox.Show("TellerID or Password is incorrect.");
            }
                Teller_TB.Text = CurrentTellerID;
                TellerID = CurrentTellerID;
                Tell_User_TB.Text = "";
                Tell_Pass_TB.Text = "";
        }
        private void ManagerLogin_Btn_Click(object sender, RoutedEventArgs e)
        {
            string CurrentManID = Man_User_TB.Text;
            string CurrentPassword = Man_Pass_TB.Text;
            double TotalSales = 0;
            if (CurrentManID == "" || CurrentPassword == "")
            {
                MessageBox.Show("ManagerID or Password is missing.");
            }
            else if (ManagerPasswords.ContainsKey(CurrentManID))
            {
                if (CurrentPassword == ManagerPasswords[CurrentManID])
                {
                    ManagerLogin.Visibility = Visibility.Hidden;
                    managerside.Visibility = Visibility.Visible;
                }
                else
                {
                    MessageBox.Show("ManagerID or Passwrd is incorrect.");
                }
            }
            else
            {
                MessageBox.Show("ManagerID or Password is incorrect.");
            }
         
            Man_User_TB.Text = "";
            Man_Pass_TB.Text = "";
                      
            string [] AllOrders = File.ReadAllLines("AllOrders.Txt");
            foreach ( string Line in AllOrders)
            {
                string[] Temp = Line.Split(';');
                TotalSales += Convert.ToDouble(Temp[3].Substring(14));
            }


            for (int j = 0; j < AllOrders.Length; j++)
            {
                AllOrderBox.Text += AllOrders[j] + "\n";
            }

            TotalSales_TB.Text = $"R{Convert.ToString(TotalSales)}";
        }


        //Methods for creating the Customer, takeaway and delivery reciepts:
        double CalculateTotal(Order CustOrder)
        {
            double total = 0;
            foreach (FoodItem Food in CustOrder.Orders)
            {
                total += Food.Price;
            }
            return total;

        }
        string CustomerReceipt(Order CustOrder, double Cost)
        {
            string Header = "THE SHIFTERS CAFE\nGrahamstown\n012 3456 789";
            string Order = "";

            foreach (FoodItem Food in CustOrder.Orders)
            {
                Order += $"{Food.ToString()}\n";
            }

            return string.Format("{0}\n\nTeller: {1}\n\n{2}\n\nTotal: R{3}", Header, TellerID, Order, Convert.ToString(Cost));
        }
        string DeliveryReceipt(Order CustOrder, string CN, string CC, string CA, double Cost)
        {
            string Header = "THE SHIFTERS CAFE\nGrahamstown\n012 3456 789";
            string Order = "";
            string CustomerDetails = string.Format("Customer: {0}\nContact: {1}\nAddress: {2} ({3})", CN, CC, CA, CampusName);
            foreach (FoodItem Food in CustOrder.Orders)
            {
                Order += $"{Food.ToString()}\n";
            }

            return string.Format("{0}\n\n{1}\n\nTeller: {2}\n\n{3}\n\nTotal: R{4}\n\nOrder Number: {5}", Header, CustomerDetails, TellerID, Order, Convert.ToString(Cost), OrderNumber);
        }
        string TakeawayReceipt(Order CustOrder, double Cost, double paid, double change)
        {
            string Header = "THE SHIFTERS CAFE\nGrahamstown\n012 3456 789";
            string Order = "";

            foreach (FoodItem Food in CustOrder.Orders)
            {
                Order += $"{Food.ToString()}\n";
            }

            return string.Format("{0}\n\nTeller: {1}\n\n{2}\n\nTotal: R{3}\nAmount Paid: R{5}\nChange: R{6}\n\nOrder Number: {4}", Header, TellerID, Order, Convert.ToString(Cost), OrderNumber, paid, change);
        }


        //Buttons for completing the orders
        private void OrderDone_Btn_Click(object sender, RoutedEventArgs e)
        {
            double CustTotal = CalculateTotal(CurrentOrder);

            if (Delivery_CB.IsChecked == false && Takeaway_CB.IsChecked == false)
            {
                MessageBox.Show("Please select Delivery or Takeaway");
            }
            else if (Delivery_CB.IsChecked == true)
            {
                try
                {
                    string CustomerName = CustName_TB.Text;
                    string CustomerContact = CustCont_TB.Text;
                    string CustomerAddress = CustAddress_TB.Text;

                    bool CustNameFormat = true;
                    bool CustContactFormat = true;
                    bool CustAddressFormat = true;


                    //Check Customer details are in the correct format:
                    foreach (char letter in CustomerName)
                    {
                        if (!char.IsLetter(letter))
                        {
                            MessageBox.Show("Please enter a valid name");
                            CustNameFormat = false;
                            break;
                        }
                    }
                    if (CustomerContact.Length != 10)
                    {
                        MessageBox.Show("Please enter a valid number");
                        CustContactFormat = false;
                    }
                    foreach (char number in CustomerContact)
                    {
                        if (!char.IsNumber(number))
                        {
                            MessageBox.Show("Please enter a valid number");
                            CustContactFormat = false;
                            break;
                        }
                    }
                    Takeaway_CB.IsChecked = false;
                    if (CustomerName == "" || CustomerContact == "" || CustomerAddress == "")
                    {
                        MessageBox.Show("Please supply customer details");
                    }
                    else
                    {
                        if (LowerCampus.Contains(CustomerAddress))
                        {
                            LowerDriver.Orders.Add(CurrentOrder);
                            CampusName = "LOWER";
                            LCD_LB.Items.Refresh();
                        }
                        else if (MiddleCampus.Contains(CustomerAddress))
                        {
                            MiddleDriver.Orders.Add(CurrentOrder);
                            CampusName = "MIDDLE";
                            MCD_LB.Items.Refresh();
                        }
                        else if (UpperCampus.Contains(CustomerAddress))
                        {
                            UpperDriver.Orders.Add(CurrentOrder);
                            CampusName = "UPPER";
                            UCD_LB.Items.Refresh();
                        } else
                        {
                            MessageBox.Show("Please enter a valid Residence");
                            CustAddressFormat = false;
                        }
                        if (CustNameFormat == true && CustContactFormat == true && CustAddressFormat == true)
                        {
                            MessageBox.Show(CustomerReceipt(CurrentOrder, CustTotal));
                            MessageBox.Show(DeliveryReceipt(CurrentOrder, CustomerName, CustomerContact, CustomerAddress, CustTotal));
                        }
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Customer details have not been supplied.");
                }
            } else if (Takeaway_CB.IsChecked == true)
            {
                try
                {
                    double AmtPaid = Convert.ToDouble(TotalPd_TB.Text);
                    double Change = AmtPaid - CustTotal;
                    Change_TB.Text = Convert.ToString(Change);

                    bool ChangeCorrect = true;

                    if (Change < 0)
                    {
                        MessageBox.Show("The customer has not paid enough");
                        ChangeCorrect = false;
                    }

                    if (ChangeCorrect == true)
                    {
                        Takeaway.Orders.Add(CurrentOrder);
                        Takeaway_LB.Items.Refresh();
                        MessageBox.Show(TakeawayReceipt(CurrentOrder, CustTotal, AmtPaid, Change));
                    }

                    Delivery_CB.IsChecked = false;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Has the amount paid been entered correctly?");
                }

            }

            CurrentOrder.orderNumber = OrderNumber;
            CumulativeTotal += CustTotal;
            TotalSales_TB.Text = $"R{Convert.ToString(Math.Round(CumulativeTotal, 2))}";

            Takeaway_CB.IsChecked = false;
            Delivery_CB.IsChecked = false;

           

            StreamWriter AllOrders = File.AppendText("AllOrders.Txt");
            foreach (FoodItem Food in CurrentOrder.Orders)
            {
                AllOrders.Write($"Order Number: {OrderNumber}; Teller: { TellerID }; Order Name : {Food.Name}; Total Cost: R{Food.Price} ");
                AllOrders.WriteLine();
                
            }
            AllOrders.Close();


        }

        //method to show all items bought at the end of the day
        public void endofdaysolditems(string solditems)
        {

        }
        private void button_Click_1(object sender, RoutedEventArgs e)
        {
            int ItemPos = OrderLB.SelectedIndex;
            int k = 0;
            if (CurrentOrder.Orders.Count == 0 || OrderLB.SelectedIndex == -1)
            {
             
                MessageBox.Show("There is nothing to remove");
            }
            else
            {
                //ManagerLogin.Visibility = Visibility.Visible;
                FoodItem ItemToRemove = CurrentOrder.Orders[ItemPos];
                while (k < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(ItemToRemove))
                    {
                        if (ItemToRemove.Quantity > 1)
                        {
                            ItemToRemove.Quantity--;
                            break;
                        }
                        else
                        {
                            CurrentOrder.Orders.Remove(ItemToRemove);
                            break;
                        }
                        k++;
                    }
                }
            }
            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            OrderNumber ++;
            OrderNumber_TB.Text = Convert.ToString(OrderNumber);
            CurrentOrder = new Order();
            OrderLB.ItemsSource = CurrentOrder.Orders;
            Change_TB.Text = "";
            TotalPd_TB.Text = "";
            TotalCost_TB.Text = "";
            CustName_TB.Text = "";
            CustCont_TB.Text = "";
            CustAddress_TB.Text = "";
        }

        private void Delivery_CB_Checked(object sender, RoutedEventArgs e)
        {

        }
        private void Delivery_CB_Checked_1(object sender, RoutedEventArgs e)
        {
        }

        private void Tell_Pass_TB_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }
    }
}
