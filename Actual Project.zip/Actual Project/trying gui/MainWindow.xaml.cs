﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Threading;


namespace trying_gui
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// defining the images
    public enum size : long { Small = (long)0.5, Standard = 1, Large = (long)1.5 }
    public partial class MainWindow : Window
    {
        DispatcherTimer TheTimer;
        public int currentstate = 0;
        int OrderNumber = 1;
        double CumulativeTotal;
        string CampusName = "";
        string TellerID = "";
        string ManagerID = "";
        public BitmapImage[] Cartpic;
        string imageintheproject = "pack://application:,,,/";
        Order CurrentOrder;
        string ordernumber = "";
        List<BoxItems> BoxItemTemp;
        Menu FullMenu;

        Dictionary<string, string> TellerPasswords;
        Dictionary<string, string> ManagerPasswords;
        Dictionary<string, double> SummaryInfo;
        List<string> SummaryInfoList;
        List<string> MostPopularList;

        List<string> LowerCampus;
        List<string> MiddleCampus;
        List<string> UpperCampus;

        Drivers LowerDriver;
        Drivers MiddleDriver;
        Drivers UpperDriver;
        Drivers Takeaway;

        //List<Order> LowerOrders;
        //List<Order> MiddleOrders;
        //List<Order> UpperOrders;
        public MainWindow()
        {
            InitializeComponent();
            // Canvas visibility
            maindoor.Visibility = Visibility.Visible;
            managerside.Visibility = Visibility.Hidden;
            employeeside.Visibility = Visibility.Hidden;
            EmployeeLogin.Visibility = Visibility.Hidden;
            ManagerLogin.Visibility = Visibility.Hidden;


            //Initialise Timer
            TheTimer = new DispatcherTimer();
            TheTimer.Interval = TimeSpan.FromMilliseconds(100);
            TheTimer.IsEnabled = true;
            TheTimer.Tick += dispatcherTimer_Tick;


            //Uploading Menu:
            //1.Food Itmes: burgers and pizza
            FullMenu = new Menu();
            CurrentOrder = new Order();
            BoxItemTemp = new List<BoxItems>();

            if (File.Exists("Food.txt"))
            {
                FullMenu.Load("Food.txt");
            }
            FoodLB.ItemsSource = FullMenu.Foods;
            ExtrasLB.ItemsSource = FullMenu.Extras;
            DrinksLB.ItemsSource = FullMenu.Drinks;
            BoxMealsLB.ItemsSource = FullMenu.BoxItems;
            SodasLB.ItemsSource = FullMenu.Sodas;
            DessertLB.ItemsSource = FullMenu.Desserts;
            OrderLB.ItemsSource = CurrentOrder.Orders;


            //Loading Campus
            LowerCampus = new List<string>();
            MiddleCampus = new List<string>();
            UpperCampus = new List<string>();
            if (File.Exists("Campuses.txt"))
            {
                LoadCampuses("Campuses.txt", LowerCampus, MiddleCampus, UpperCampus);
            }


            LowerDriver = new Drivers();
            MiddleDriver = new Drivers();
            UpperDriver = new Drivers();
            Takeaway = new Drivers();

            //TakeawayLB.ItemsSource = FullMenu.Foods;
            LCD_LB.ItemsSource = LowerDriver.Orders;
            MCD_LB.ItemsSource = MiddleDriver.Orders;
            UCD_LB.ItemsSource = UpperDriver.Orders;
            Takeaway_LB.ItemsSource = Takeaway.Orders;

            //PASSWORDS

            if (File.Exists("Teller Passwords.txt"))
            {
                TellerPasswords = LoadTellerPasswords("Teller Passwords.txt");
            }

            if (File.Exists("Manager Passwords.txt"))
            {
                ManagerPasswords = LoadManagerPasswords("Manager Passwords.txt");
            }

            //Loading summary info
            if (File.Exists("FoodSummary.txt"))
            {
                SummaryInfo = LoadSummary("FoodSummary.txt");
                MostPopularList = FindMostPopular("FoodSummary.txt");
                SummaryInfoList = LoadSummaryToList("FoodSummary.txt");
            }
            Summary_LB.ItemsSource = SummaryInfoList;
            Popular_Lb.ItemsSource = MostPopularList;
            //  CumulativeTotal = SummaryInfo["Total Sales"];
        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {

        }

        //void dissapear()
        //{
        //    if (manager.IsPressed == true)
        //    {
        //        managerside.Visibility = Visibility.Visible;
        //    }
        //    else managerside.Visibility = Visibility.Hidden;
        //    if (employee.IsPressed == true)
        //    {
        //        .Visibility = Visibility.Visible;

        //    }
        //    else
        //}
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            managerside.Visibility = Visibility.Hidden;
            maindoor.Visibility = Visibility.Hidden;
            employeeside.Visibility = Visibility.Hidden;
            ManagerLogin.Visibility = Visibility.Visible;
        }

        private void employee_Click(object sender, RoutedEventArgs e)
        {
            employeeside.Visibility = Visibility.Hidden;
            maindoor.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
            //   cartimage.Source = Cartpic[currentstate];
            EmployeeLogin.Visibility = Visibility.Visible;

        }

        private void logoutmanager_Click(object sender, RoutedEventArgs e)
        {
            maindoor.Visibility = Visibility.Visible;
            employeeside.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
        }

        private void logoutemployee_Click(object sender, RoutedEventArgs e)
        {
            employeeside.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
            maindoor.Visibility = Visibility.Visible;
        }

        private void cartimage_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void ListBoxItem_Selected(object sender, RoutedEventArgs e)
        {

        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ListBoxItem_Selected_1(object sender, RoutedEventArgs e)
        {

        }

        private void cartimage_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void checkBox4_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void FoodDesBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        //Loading and Saving Methods for Passwords and Residences and Summary
        Dictionary<string, string> LoadTellerPasswords(string filename)
        {
            string readTellers = File.ReadAllText(filename);
            string[] Tellers = readTellers.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

            Dictionary<string, string> TellerPassowrds = new Dictionary<string, string>();

            foreach (string Teller in Tellers)
            {
                if (Teller == "") break;
                string[] TempTeller = Teller.Split(';');
                TellerPassowrds[TempTeller[0]] = TempTeller[1];
            }

            return TellerPassowrds;
        }
        Dictionary<string, string> LoadManagerPasswords(string filename)
        {
            string readManagers = File.ReadAllText(filename);
            string[] Managers = readManagers.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

            Dictionary<string, string> ManagerPassowrds = new Dictionary<string, string>();

            foreach (string Manager in Managers)
            {
                string[] TempTeller = Manager.Split(';');
                ManagerPassowrds[TempTeller[0]] = TempTeller[1];
            }

            return ManagerPassowrds;
        }
        Dictionary<string, double> LoadSummary(string filename)
        {
            string readSummary = File.ReadAllText(filename);
            string[] Summary = readSummary.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

            Dictionary<string, double> SummaryInfo = new Dictionary<string, double>();

            foreach (string Item in Summary)
            {
                if (Item == "") break;
                string[] TempItem = Item.Split(';');
                SummaryInfo[TempItem[0]] = Convert.ToDouble(TempItem[1]);
            }
            return SummaryInfo;
        }
        List<string> LoadSummaryToList(string filename)
        {
            string readSummary = File.ReadAllText(filename);
            string[] Summary = readSummary.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

            List<string> SummaryInfoList = new List<string>();

            for (int i = 3; i < Summary.Length; i++)
            {
                string Item = Summary[i];
                if (Item == "") break;
                string[] TempItem = Item.Split(';');
                SummaryInfoList.Add($"{TempItem[1]}x {TempItem[0]}");
            }
            return SummaryInfoList;
        }
        void SaveSummary(string filename)
        {
            StreamWriter SummaryOrders = File.CreateText("FoodSummary.Txt");
            foreach (string k in SummaryInfo.Keys)
            {
                SummaryOrders.WriteLine(string.Format("{0};{1}", k, SummaryInfo[k]));
            }
            SummaryOrders.Close();
        }
        void AddToDictionaryCount(string FoodName)
        {
            foreach (string k in SummaryInfo.Keys)
            {
                if (FoodName == $"{k} ")
                {
                    SummaryInfo[k]++;
                    break;
                }
            }
        }
        void ResetSummary(string filename)
        {
            StreamWriter SummaryOrders = File.CreateText(filename);
            int b = 0;
            foreach (string k in SummaryInfo.Keys)
            {
                SummaryOrders.WriteLine(string.Format("{0};{1}", k, b));
            }
            SummaryOrders.Close();
        }
        public void LoadCampuses(string filename, List<string> Lower, List<string> Middle, List<string> Upper)
        {

            string readAddresses = File.ReadAllText(filename);
            string[] Res = readAddresses.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);
            string Campus = "";

            for (int i = 0; i < Res.Length; i++)
            {
                string Item = Res[i];
                string[] Temp = Item.Split(':');
                if (Item == "")
                {
                    i++;
                    Item = Res[i];
                    Temp = Item.Split(':');
                }
                if (Item.Contains(':'))
                {
                    Campus = Item.Split(':')[1];
                    i++;
                    Item = Res[i];
                }
                if (Campus == "LOWER")
                {
                    Lower.Add(Item);
                }
                else if (Campus == "MIDDLE")
                {
                    Middle.Add(Item);
                }
                else if (Campus == "UPPER")
                {
                    Upper.Add(Item);
                }
            }
        }

        //Most Popular Itme Method
        List<string> FindMostPopular(string filename)
        {
            string readSummary = File.ReadAllText(filename);
            string[] Summary = readSummary.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

            List<string> PopularOrders = new List<string>();
            List<int> NumericPopularOrders = new List<int>();
            for (int i = 3; i < Summary.Length; i++)
            {
                string Item = Summary[i];
                if (Item == "") break;
                int TempItem = Convert.ToInt32(Item.Split(';')[1]);
                NumericPopularOrders.Add(TempItem);
            }

            int BiggestCount = NumericPopularOrders.Max();
            if (BiggestCount != 0)
            {
                for (int i = 3; i < Summary.Length; i++)
                {
                    string Item = Summary[i];
                    if (Item == "") break;
                    string[] TempItem = Item.Split(';');
                    if (Convert.ToInt32(TempItem[1]) >= BiggestCount)
                    {
                        PopularOrders.Add(TempItem[0]);
                    }
                }
            } else
            {

            }
            return PopularOrders;
        }

        //Displaying the description of each menu item
        private void BurgersLB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ItemPosB = FoodLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Foods[ItemPosB];
            FoodDesBox.Text = CurrentB.Description.ToString();
        }
        private void ExtrasLB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ItemPosB = ExtrasLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Extras[ItemPosB];
            ExtrasDes_TB.Text = CurrentB.Description.ToString();
        }
        private void BoxMealsLB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ItemPosB = BoxMealsLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.BoxItems[ItemPosB];
            BoxDes_TB.Text = CurrentB.Description.ToString();
        }
        private void DessertLB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ItemPosB = DessertLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Desserts[ItemPosB];
            DessertDes_TB.Text = CurrentB.Description.ToString();
        }
        private void DrinksLB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ItemPosB = DrinksLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Drinks[ItemPosB];
            DrinksDes_TB.Text = CurrentB.Description.ToString();
        }


        //Add Item Buttons
        private void AddMeal_Btn_Click(object sender, RoutedEventArgs e)
        {
            int ItemPos = FoodLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Foods[ItemPos];
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
                AddToDictionaryCount(CurrentB.Name);
            }
            else
            {
                int i = CurrentOrder.Orders.IndexOf(CurrentB);
                if (i != -1)
                {
                    CurrentB.Quantity++;
                    AddToDictionaryCount(CurrentB.Name);                   
                }
                else
                {
                    CurrentOrder.Orders.Add(CurrentB);
                    AddToDictionaryCount(CurrentB.Name);                 
                }              
            }
            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }
        private void AddDessert_Btn_Click_1(object sender, RoutedEventArgs e)
        {
            int ItemPos = DessertLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Desserts[ItemPos];
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
                AddToDictionaryCount(CurrentB.Name);
            }
            else
            {
                int i = CurrentOrder.Orders.IndexOf(CurrentB);
                if (i != -1)
                {
                    CurrentB.Quantity++;
                    AddToDictionaryCount(CurrentB.Name);
                }
                else
                {
                    CurrentOrder.Orders.Add(CurrentB);
                    AddToDictionaryCount(CurrentB.Name);
                }
            }
            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }
        private void AddBoxitem_Btn_Click(object sender, RoutedEventArgs e)
        {
            if (BoxMealsLB.SelectedIndex == -1 || SodasLB.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a BoxMeal and a drink.");
            }
            else
            {
                int ItemPos = BoxMealsLB.SelectedIndex;
                int DrinkPos = SodasLB.SelectedIndex;

                FoodItem CurrentB = new FoodItem(FullMenu.BoxItems[ItemPos].Name, FullMenu.BoxItems[ItemPos].Description, FullMenu.BoxItems[ItemPos].Price);
                string CurrentName = FullMenu.BoxItems[ItemPos].Name;
                CurrentB.BoxDrink = FullMenu.Sodas[DrinkPos].Name;


                FoodItem CurrentC;
                if (CurrentOrder.Orders.Count == 0)
                {
                    CurrentOrder.Orders.Add(CurrentB);
                    AddToDictionaryCount(CurrentName);
                    AddToDictionaryCount(CurrentB.BoxDrink);
                }
                else
                {
                    int j = CurrentOrder.Orders.IndexOf((CurrentB));
                    if (j != -1)
                    {
                        CurrentOrder.Orders[j].Quantity++;
                        AddToDictionaryCount(CurrentName);
                        AddToDictionaryCount(CurrentB.BoxDrink);
                    }
                    else
                    {
                        if (FullMenu.BoxItems[ItemPos].name == "Beef Burger Meal")
                        {
                            CurrentName = "Beef Burger Meal";
                            FullMenu.BoxItems[ItemPos].Name = CurrentName;
                        }
                        if (FullMenu.BoxItems[ItemPos].name == "Chicken Burger Meal")
                        {
                            CurrentName = "Chicken Burger Meal";
                            FullMenu.BoxItems[ItemPos].Name = CurrentName;
                        }
                        if (FullMenu.BoxItems[ItemPos].name == "Mutton Burger Meal")
                        {
                            CurrentName = "Mutton Burger Meal";
                            FullMenu.BoxItems[ItemPos].Name = CurrentName;
                        }
                        if (FullMenu.BoxItems[ItemPos].name == "Supreme Beef Burger Meal")
                        {
                            CurrentName = "Supreme Beef Burger Meal";
                            FullMenu.BoxItems[ItemPos].Name = CurrentName;
                        }
                        CurrentC = new FoodItem(FullMenu.BoxItems[ItemPos].name, FullMenu.BoxItems[ItemPos].Description, FullMenu.BoxItems[ItemPos].price);
                        CurrentC.BoxDrink = FullMenu.Sodas[DrinkPos].Name;
                        int i = CurrentOrder.Orders.IndexOf((CurrentC));
                        CurrentOrder.Orders.Add(CurrentC);
                        AddToDictionaryCount($"{CurrentName} ");
                        AddToDictionaryCount(CurrentC.BoxDrink);
                        if (i != -1)
                        {
                            CurrentOrder.Orders[i].Quantity++;
                            AddToDictionaryCount(CurrentName);
                            AddToDictionaryCount(CurrentB.BoxDrink);
                        }
                    }
                }
            }
            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }
        private void AddDrink_Btn_Click(object sender, RoutedEventArgs e)
        {
            int ItemPos = DrinksLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Drinks[ItemPos];
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
                AddToDictionaryCount(CurrentB.Name);
            }
            else
            {
                int i = CurrentOrder.Orders.IndexOf(CurrentB);
                if (i != -1)
                {
                    CurrentB.Quantity++;
                    AddToDictionaryCount(CurrentB.Name);
                }
                else
                {
                    CurrentOrder.Orders.Add(CurrentB);
                    AddToDictionaryCount(CurrentB.Name);
                }
            }
            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }
        private void AddExtras_Btn_Click(object sender, RoutedEventArgs e)
        {
            int ItemPos = ExtrasLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Extras[ItemPos];
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
                AddToDictionaryCount(CurrentB.Name);
            }
            else
            {
                int i = CurrentOrder.Orders.IndexOf(CurrentB);
                if (i != -1)
                {
                    CurrentB.Quantity++;
                    AddToDictionaryCount(CurrentB.Name);
                }
                else
                {
                    CurrentOrder.Orders.Add(CurrentB);
                    AddToDictionaryCount(CurrentB.Name);
                }
            }
            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }


        //Manager and Teller Login Buttons
        private void Tell_Login_Btn_Click(object sender, RoutedEventArgs e)
        {
            string CurrentTellerID = Tell_User_TB.Text;
            string CurrentPassword = Tell_Pass_PB.Password;
            if(CurrentTellerID == "" || CurrentPassword == "")
            {
                MessageBox.Show("TellerID or Password is missing.");
            } else if (TellerPasswords.ContainsKey(CurrentTellerID))
                {
                    if (CurrentPassword == TellerPasswords[CurrentTellerID])
                    {
                        EmployeeLogin.Visibility = Visibility.Hidden;
                        employeeside.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        MessageBox.Show("TellerID or Passwrd is incorrect.");
                    }
                } else
            {
                MessageBox.Show("TellerID or Password is incorrect.");
            }
                Teller_TB.Text = CurrentTellerID;
                TellerID = CurrentTellerID;
                Tell_User_TB.Text = "";
                Tell_Pass_PB.Password = "";
        }
        private void ManagerLogin_Btn_Click(object sender, RoutedEventArgs e)
        {
            string CurrentManID = Man_User_TB.Text;
            string CurrentPassword = Man_Pass_PB.Password;
            if (CurrentManID == "" || CurrentPassword == "")
            {
                MessageBox.Show("ManagerID or Password is missing.");
            }
            else if (ManagerPasswords.ContainsKey(CurrentManID))
            {
                if (CurrentPassword == ManagerPasswords[CurrentManID])
                {
                    ManagerLogin.Visibility = Visibility.Hidden;
                    managerside.Visibility = Visibility.Visible;
                
                }
                else
                {
                    MessageBox.Show("ManagerID or Passwrd is incorrect.");
                }
            }
            else
            {
                MessageBox.Show("ManagerID or Password is incorrect.");
            }
         
            Man_User_TB.Text = "";
            Man_Pass_PB.Password = "";

            string[] AllOrders = File.ReadAllLines("AllOrders.Txt");
            for (int j = 0; j < AllOrders.Length; j++)
            {
                AllOrderBox.Text += AllOrders[j] + "\n";
            }

            NewTotalSales_TB.Text = string.Format("{0:C}", SummaryInfo["Total Sales"]);
            TASales_TB.Text = Convert.ToString(SummaryInfo["Takeaway Sales"]);
            DSales_TB.Text = Convert.ToString(SummaryInfo["Delivery Sales"]);

            if (File.Exists("FoodSummary.txt"))
            {
                SummaryInfo = LoadSummary("FoodSummary.txt");
                MostPopularList = FindMostPopular("FoodSummary.txt");
                SummaryInfoList = LoadSummaryToList("FoodSummary.txt");
            }
            Summary_LB.ItemsSource = SummaryInfoList;
            Summary_LB.Items.Refresh();
            Popular_Lb.ItemsSource = MostPopularList;
            Popular_Lb.Items.Refresh();
            NewTotalSales_TB.Text = string.Format("{0:C}", SummaryInfo["Total Sales"]);
            TASales_TB.Text = Convert.ToString(SummaryInfo["Takeaway Sales"]);
            DSales_TB.Text = Convert.ToString(SummaryInfo["Delivery Sales"]);
        }


        //Methods for creating the Customer, takeaway and delivery reciepts:
        double CalculateTotal(Order CustOrder)
        {
            double total = 0;
            foreach (FoodItem Food in CustOrder.Orders)
            {
                total += Food.Price;
            }
            return total;

        }
        string CustomerReceipt(Order CustOrder, double Cost)
        {
            string Header = "THE SHIFTERS CAFE\nGrahamstown\n012 3456 789";
            string Order = "";

            foreach (FoodItem Food in CustOrder.Orders)
            {
                Order += $"{Food.ToString()}\n";
            }

            return string.Format("{0}\n\nTeller: {1}\n\n{2}\n\nTotal: {3:C}", Header, TellerID, Order, Cost);
        }
        string DeliveryReceipt(Order CustOrder, string CN, string CC, string CA, double Cost)
        {
            string Header = "THE SHIFTERS CAFE\nGrahamstown\n012 3456 789";
            string Order = "";
            string CustomerDetails = string.Format("Customer: {0}\nContact: {1}\nAddress: {2} ({3})", CN, CC, CA, CampusName);
            foreach (FoodItem Food in CustOrder.Orders)
            {
                Order += $"{Food.ToString()}\n";
            }

            return string.Format("{0}\n\n{1}\n\nTeller: {2}\n\n{3}\n\nTotal: {4:C}\n\nOrder Number: {5}", Header, CustomerDetails, TellerID, Order, Cost, OrderNumber);
        }
        string TakeawayReceipt(Order CustOrder, double Cost, double paid, double change)
        {
            string Header = "THE SHIFTERS CAFE\nGrahamstown\n012 3456 789";
            string Order = "";

            foreach (FoodItem Food in CustOrder.Orders)
            {
                Order += $"{Food.ToString()}\n";
            }

            return string.Format("{0}\n\nTeller: {1}\n\n{2}\n\nTotal: {3:C}\nAmount Paid: {5:C}\nChange: {6:C}\n\nOrder Number: {4}", Header, TellerID, Order, Cost, OrderNumber, paid, change);
        }



        //Buttons for completing the orders
        private void OrderDone_Btn_Click(object sender, RoutedEventArgs e)
        {
            double CustTotal = CalculateTotal(CurrentOrder);

            if (Delivery_CB.IsChecked == false && Takeaway_CB.IsChecked == false)
            {
                MessageBox.Show("Please select Delivery or Takeaway");
            }
            else if (Delivery_CB.IsChecked == true)
            {
                try
                {
                    string CustomerName = CustName_TB.Text;
                    string CustomerContact = CustCont_TB.Text;
                    string CustomerAddress = CustAddress_TB.Text;

                    bool CustNameFormat = true;
                    bool CustContactFormat = true;
                    bool CustAddressFormat = true;

                    //Check Customer details are in the correct format:
                    foreach (char letter in CustomerName)
                    {
                        if (!char.IsLetter(letter))
                        {
                            MessageBox.Show("Please enter a valid name");
                            CustNameFormat = false;
                            break;
                        }
                    }
                    if (CustomerContact.Length != 10)
                    {
                        MessageBox.Show("Please enter a valid number");
                        CustContactFormat = false;
                    }
                    foreach (char number in CustomerContact)
                    {
                        if (!char.IsNumber(number))
                        {
                            MessageBox.Show("Please enter a valid number");
                            CustContactFormat = false;
                            break;
                        }
                    }
                    Takeaway_CB.IsChecked = false;
                    if (CustomerName == "" || CustomerContact == "" || CustomerAddress == "")
                    {
                        MessageBox.Show("Please supply customer details");
                    }
                    else
                    {
                        if (LowerCampus.Contains(CustomerAddress))
                        {
                            LowerDriver.Orders.Add(CurrentOrder);
                            CampusName = "LOWER";
                            LCD_LB.Items.Refresh();
                        }
                        else if (MiddleCampus.Contains(CustomerAddress))
                        {
                            MiddleDriver.Orders.Add(CurrentOrder);
                            CampusName = "MIDDLE";
                            MCD_LB.Items.Refresh();
                        }
                        else if (UpperCampus.Contains(CustomerAddress))
                        {
                            UpperDriver.Orders.Add(CurrentOrder);
                            CampusName = "UPPER";
                            UCD_LB.Items.Refresh();
                        } else
                        {
                            MessageBox.Show("Please enter a valid Residence");
                            CustAddressFormat = false;
                        }
                        if (CustNameFormat == true && CustContactFormat == true && CustAddressFormat == true)
                        {
                            MessageBox.Show(CustomerReceipt(CurrentOrder, CustTotal));
                            MessageBox.Show(DeliveryReceipt(CurrentOrder, CustomerName, CustomerContact, CustomerAddress, CustTotal));
                            SummaryInfo["Delivery Sales"]++;
                        }
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Customer details have not been supplied.");
                }
            } else if (Takeaway_CB.IsChecked == true)
            {
                try
                {
                    double AmtPaid = Convert.ToDouble(TotalPd_TB.Text);
                    double Change = AmtPaid - CustTotal;
                    Change_TB.Text = Convert.ToString(Change);

                    bool ChangeCorrect = true;

                    if (Change < 0)
                    {
                        MessageBox.Show("The customer has not paid enough");
                        ChangeCorrect = false;
                    }

                    if (ChangeCorrect == true)
                    {
                        Takeaway.Orders.Add(CurrentOrder);
                        Takeaway_LB.Items.Refresh();
                        MessageBox.Show(TakeawayReceipt(CurrentOrder, CustTotal, AmtPaid, Change));
                        SummaryInfo["Takeaway Sales"] ++;
                    }

                    Delivery_CB.IsChecked = false;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Has the amount paid been entered correctly?");
                }

            }

            CurrentOrder.orderNumber = OrderNumber;
            SummaryInfo["Total Sales"] += CustTotal;

            Takeaway_CB.IsChecked = false;
            Delivery_CB.IsChecked = false;

            //StreamWriter AllOrders = File.AppendText("AllOrders.Txt");
            //foreach (FoodItem Food in CurrentOrder.Orders)
            //{
            //    AllOrders.Write($"Order Number: {OrderNumber}; Teller: { TellerID }; Order Name : {Food.Name}; Total Cost: R{Food.Price} ");
            //    AllOrders.WriteLine(); 
            //}
            //AllOrders.Close();

            //Save To All End of day sales
            StreamWriter AllOrders = File.AppendText("AllOrders.Txt");
            AllOrders.WriteLine($"Order Number: {OrderNumber}");
            AllOrders.WriteLine($"Teller: { TellerID }");
            foreach (FoodItem Food in CurrentOrder.Orders)
            {
                AllOrders.WriteLine(Food.ToString());     
            }
            AllOrders.WriteLine(string.Format("Total Cost: {0:C}", CustTotal));
            AllOrders.WriteLine();
            AllOrders.Close();

            //Update sumamry file
            SaveSummary("FoodSummary.txt");
            if (File.Exists("FoodSummary.txt"))
            {
                SummaryInfo = LoadSummary("FoodSummary.txt");
                MostPopularList = FindMostPopular("FoodSummary.txt");
                SummaryInfoList = LoadSummaryToList("FoodSummary.txt");
            }
            Summary_LB.ItemsSource = SummaryInfoList;
            Summary_LB.Items.Refresh();
            Popular_Lb.ItemsSource = MostPopularList;
            Popular_Lb.Items.Refresh();
            NewTotalSales_TB.Text = string.Format("{0:C}", SummaryInfo["Total Sales"]);
            TASales_TB.Text = Convert.ToString(SummaryInfo["Takeaway Sales"]);
            DSales_TB.Text = Convert.ToString(SummaryInfo["Delivery Sales"]);
        }

        //method to show all items bought at the end of the day
        public void endofdaysolditems(string solditems)
        {

        }
        private void button_Click_1(object sender, RoutedEventArgs e)
        {
            int ItemPos = OrderLB.SelectedIndex;
            int k = 0;
            if (CurrentOrder.Orders.Count == 0 || OrderLB.SelectedIndex == -1)
            {
             
                MessageBox.Show("There is nothing to remove");
            }
            else
            {
                //ManagerLogin.Visibility = Visibility.Visible;
                FoodItem ItemToRemove = CurrentOrder.Orders[ItemPos];
                while (k < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(ItemToRemove))
                    {
                        if (ItemToRemove.Quantity > 1)
                        {
                            ItemToRemove.Quantity--;
                            break;
                        }
                        else
                        {
                            CurrentOrder.Orders.Remove(ItemToRemove);
                            break;
                        }
                        k++;
                    }
                }
            }
            OrderLB.Items.Refresh();
            TotalCost_TB.Text = Convert.ToString(CalculateTotal(CurrentOrder));
        }
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            OrderNumber ++;
            OrderNumber_TB.Text = Convert.ToString(OrderNumber);
            CurrentOrder = new Order();
            OrderLB.ItemsSource = CurrentOrder.Orders;
            Change_TB.Text = "";
            TotalPd_TB.Text = "";
            TotalCost_TB.Text = "";
            CustName_TB.Text = "";
            CustCont_TB.Text = "";
            CustAddress_TB.Text = "";
        }

        private void Delivery_CB_Checked(object sender, RoutedEventArgs e)
        {

        }
        private void Delivery_CB_Checked_1(object sender, RoutedEventArgs e)
        {
        }

        private void Tell_Pass_TB_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }

        private void Reset_Btn_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists("FoodSummary.txt"))
            {

                ResetSummary("FoodSummary.txt");
                SummaryInfo = LoadSummary("FoodSummary.txt");
                MostPopularList = FindMostPopular("FoodSummary.txt");
                SummaryInfoList = LoadSummaryToList("FoodSummary.txt");
            }
            Summary_LB.ItemsSource = SummaryInfoList;
            Summary_LB.Items.Refresh();
            Popular_Lb.ItemsSource = MostPopularList;
            NewTotalSales_TB.Text = string.Format("{ 0:C}", SummaryInfo["Total Sales"]);
            TASales_TB.Text = Convert.ToString(SummaryInfo["Takeaway Sales"]);
            DSales_TB.Text = Convert.ToString(SummaryInfo["Delivery Sales"]);
        }

        private void Add_NewTell_Btn_Click(object sender, RoutedEventArgs e)
        {
            string NewFName = NewTell_FN_TB.Text;
            string NewSName = NewTell_SN_TB.Text;
            NewTell_ID_TB.Text = string.Format("Tel{0}{1}", NewSName[0], NewFName[0]);
            string NewPassword = NewTell_Pass_TB.Text;

            StreamWriter NewTeller = File.AppendText("Teller Passwords.Txt");
            NewTeller.Write(string.Format("\n{0};{1};{2};{3}", NewTell_ID_TB.Text, NewPassword, NewSName, NewFName));
            NewTeller.Close();

            if (File.Exists("Teller Passwords.txt"))
            {
                TellerPasswords = LoadTellerPasswords("Teller Passwords.txt");
            }
        }
    }
}
