﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;


namespace trying_gui
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// defining the images
    public enum size { Small = 1, Standard = 2, Large = 3 }
    public partial class MainWindow : Window
    {
        public int currentstate = 0;
        public BitmapImage[] Cartpic;
        string imageintheproject = "pack://application:,,,/";
        Order CurrentOrder;
        Menu FullMenu;
        Dictionary<string, string> TellerPasswords;
        public MainWindow()
        {
            InitializeComponent();
            maindoor.Visibility = Visibility.Visible;
            managerside.Visibility = Visibility.Hidden;
            employeeside.Visibility = Visibility.Hidden;
            EmployeeLogin.Visibility = Visibility.Hidden;
            Cartpic = new BitmapImage[] {
                new BitmapImage(new Uri( imageintheproject+"shopping_cart.png"))
                };

            //Uploading Menu:
            //1.Food Itmes: burgers and pizza
            FullMenu = new Menu();
            CurrentOrder = new Order();
            if (File.Exists("Food.txt"))
            {
                FullMenu.Load("Food.txt");
            }
            FoodLB.ItemsSource = FullMenu.Foods;
            ExtrasLB.ItemsSource = FullMenu.Extras;
            DrinksLB.ItemsSource = FullMenu.Drinks;
            BoxMealsLB.ItemsSource = FullMenu.BoxItems;
            SodasLB.ItemsSource = FullMenu.Sodas;
            DessertLB.ItemsSource = FullMenu.Desserts;
            OrderLB.ItemsSource = CurrentOrder.Orders;

            if (File.Exists("Teller Passwords.txt"))
            {
                TellerPasswords = LoadTellerPasswords("Teller Passwords.txt");
            }

        }
        //void dissapear()
        //{
        //    if (manager.IsPressed == true)
        //    {
        //        managerside.Visibility = Visibility.Visible;
        //    }
        //    else managerside.Visibility = Visibility.Hidden;
        //    if (employee.IsPressed == true)
        //    {
        //        .Visibility = Visibility.Visible;

        //    }
        //    else
        //}
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            managerside.Visibility = Visibility.Visible;
            maindoor.Visibility = Visibility.Hidden;
            employeeside.Visibility = Visibility.Hidden;
        }

        private void employee_Click(object sender, RoutedEventArgs e)
        {
            employeeside.Visibility = Visibility.Hidden;
            maindoor.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
            cartimage.Source = Cartpic[currentstate];
            EmployeeLogin.Visibility = Visibility.Visible;

        }

        private void logoutmanager_Click(object sender, RoutedEventArgs e)
        {
            maindoor.Visibility = Visibility.Visible;
            employeeside.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
        }

        private void logoutemployee_Click(object sender, RoutedEventArgs e)
        {
            employeeside.Visibility = Visibility.Hidden;
            managerside.Visibility = Visibility.Hidden;
            maindoor.Visibility = Visibility.Visible;
        }

        private void cartimage_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void ListBoxItem_Selected(object sender, RoutedEventArgs e)
        {

        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ListBoxItem_Selected_1(object sender, RoutedEventArgs e)
        {

        }

        private void cartimage_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void checkBox4_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void BurgersLB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ItemPosB = FoodLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Foods[ItemPosB];
            FoodDesBox.Text = CurrentB.Description.ToString();
        }

        private void FoodDesBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        double CalculateTotal(Order CustOrder)
        {
            double total = 0;
            foreach (FoodItem Food in CustOrder.Orders)
            {
                total += Food.Price;
            }
            return total;

        }
        string CustomerReceipt(Order CustOrder, string Teller, double Cost)
        {
            string Header = "THE SHIFTERS CAFE\nGrahamstown\n012 3456 789";
            string Order = "";

            foreach(FoodItem Food in CustOrder.Orders)
            {
                Order += $"{Food.ToString()}\n";
            }

            return string.Format("{0}\n\nTeller: {1}\n\n{2}\n\nTotal: R{3}", Header, Teller, Order, Convert.ToString(Cost));
        }

        string DeliveryReceipt(Order CustOrder, string CN, string CC, string CA, string Teller, double Cost)
        {
            string Header = "THE SHIFTERS CAFE\nGrahamstown\n012 3456 789";
            string Order = "";
            string CustomerDetails = string.Format("Customer: {0}\nContact: {1}\nAddress: {2}", CN, CC, CA);
            foreach (FoodItem Food in CustOrder.Orders)
            {
                Order += $"{Food.ToString()}\n";
            }

            return string.Format("{0}\n\n{1}\n\nTeller: {2}\n\n{3}\n\nTotal: R{4}", Header, CustomerDetails, Teller, Order, Convert.ToString(Cost));
        }
        //Add Item Buttons
        private void AddMeal_Btn_Click(object sender, RoutedEventArgs e)
        {
            int ItemPos = FoodLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Foods[ItemPos];
            int k = 0;
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
            }
            else
            {
                while (k < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(CurrentB))
                    {
                        CurrentB.Quantity++;
                        break;
                    }
                    else
                    {
                        CurrentOrder.Orders.Add(CurrentB);
                        break;
                    }
                    k++;
                }
            }
            OrderLB.Items.Refresh();
        }
        private void AddDessert_Btn_Click_1(object sender, RoutedEventArgs e)
        {
            int ItemPos = DessertLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Desserts[ItemPos];
            int k = 0;
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
            }
            else
            {
                while (k < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(CurrentB))
                    {
                        CurrentB.Quantity++;
                        break;
                    }
                    else
                    {
                        CurrentOrder.Orders.Add(CurrentB);
                        break;
                    }
                    k++;
                }
            }
            OrderLB.Items.Refresh();
        }
        private void AddBoxitem_Btn_Click(object sender, RoutedEventArgs e)
        {
            int ItemPos = BoxMealsLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.BoxItems[ItemPos];
            int k = 0;
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
            }
            else
            {
                while (k < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(CurrentB))
                    {
                        CurrentB.Quantity++;
                        break;
                    }
                    else
                    {
                        CurrentOrder.Orders.Add(CurrentB);
                        break;
                    }
                    k++;
                }
            }
            OrderLB.Items.Refresh();
        }
        private void AddDrink_Btn_Click(object sender, RoutedEventArgs e)
        {
            int ItemPos = DrinksLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Drinks[ItemPos];
            int k = 0;
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
            }
            else
            {
                while (k < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(CurrentB))
                    {
                        CurrentB.Quantity++;
                        break;
                    }
                    else
                    {
                        CurrentOrder.Orders.Add(CurrentB);
                        break;
                    }
                    k++;
                }
            }
            OrderLB.Items.Refresh();
        }
        private void AddExtras_Btn_Click(object sender, RoutedEventArgs e)
        {
            int ItemPos = ExtrasLB.SelectedIndex;
            FoodItem CurrentB = FullMenu.Extras[ItemPos];
            int k = 0;
            if (CurrentOrder.Orders.Count == 0)
            {
                CurrentOrder.Orders.Add(CurrentB);
            }
            else
            {
                while (k < CurrentOrder.Orders.Count)
                {
                    if (CurrentOrder.Orders.Contains(CurrentB))
                    {
                        CurrentB.Quantity++;
                        break;
                    }
                    else
                    {
                        CurrentOrder.Orders.Add(CurrentB);
                        break;
                    }
                    k++;
                }
            }
            OrderLB.Items.Refresh();
        }

        Dictionary<string, string> LoadTellerPasswords(string filename)
        {
            string readTellers = File.ReadAllText(filename);
            string[] Tellers = readTellers.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

            Dictionary<string, string> TellerPassowrds = new Dictionary<string, string>();

            foreach (string Teller in Tellers)
            {
                string[] TempTeller = Teller.Split(';');
                TellerPassowrds[TempTeller[0]] = TempTeller[1];
            }

            return TellerPassowrds;
        }
        private void Tell_Login_Btn_Click(object sender, RoutedEventArgs e)
        {
            string CurrentUser = Tell_User_TB.Text;
            string CurrentPassword = Tell_Pass_TB.Text;
            if (TellerPasswords.ContainsKey(CurrentPassword) )
            {
                if (CurrentUser == TellerPasswords[CurrentPassword])
                {
                    EmployeeLogin.Visibility = Visibility.Hidden;
                    employeeside.Visibility = Visibility.Visible;
                }
            }

        }

        private void OrderDone_Btn_Click(object sender, RoutedEventArgs e)
        {
            double CustTotal = CalculateTotal(CurrentOrder);
            string CustomerName = CustName_TB.Text;
            string CustomerContact = CustCont_TB.Text;
            string CustomerAddress = CustAddress_TB.Text;
            string Teller = Teller_TB.Text;

            MessageBox.Show(CustomerReceipt(CurrentOrder, Teller, CustTotal));

            //if ()
            //{
            //    MessageBox.Show(DeliveryReceipt(CurrentOrder, CustomerName, CustomerContact, CustomerAddress, Teller, CustTotal));
            //}

        }

        private void Delivery_CB_Checked(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void Delivery_CB_Checked_1(object sender, RoutedEventArgs e)
        {
        }
    }
}
