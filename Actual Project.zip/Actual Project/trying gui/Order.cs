﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trying_gui
{
    class Order
    {
        public List<FoodItem> Orders { get; set; }

        public Order()
        {
            Orders = new List<FoodItem>();
        }
    }
}
